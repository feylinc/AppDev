﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02
{
    public partial class Form1 : Form
    {
        List<char> letters = new List<char>();
        List<char> display = new List<char>() { '_', '_', '_', '_', '_' };
        public Form1()
        {
            InitializeComponent();

            lb_Huruf1.Font = new Font(lb_Huruf1.Font.FontFamily, 30);
            lb_Huruf2.Font = new Font(lb_Huruf2.Font.FontFamily, 30);
            lb_Huruf3.Font = new Font(lb_Huruf3.Font.FontFamily, 30);
            lb_Huruf4.Font = new Font(lb_Huruf4.Font.FontFamily, 30);
            lb_Huruf5.Font = new Font(lb_Huruf5.Font.FontFamily, 30);
           
            panel_AfterPlay.Visible = false;
        }

        private void btn_Play_Click(object sender, EventArgs e)
        {
            List<string> words = new List<string>() { tBox_Word1.Text, tBox_Word2.Text, tBox_Word3.Text, tBox_Word4.Text, tBox_Word5.Text };
            List<string> cekWords = new List<string>();

            bool cek = false;

            foreach (string word in words)
            {
                if (word.Length == 5)
                {
                    if (cekWords.Contains(word))
                    {
                        MessageBox.Show("Terdapat kata yang sama. Silakan input ulang!");
                        break;
                    }
                    else
                    {
                        cekWords.Add(word);

                        if (cekWords.Count == 5)
                        {
                            MessageBox.Show("Let's Play");
                            cek = true;
                        }
                    }
                }
                else if (word.Length == 0)
                {
                    MessageBox.Show("Terdapat kata yang tidak diisi. Silakan diisi!");
                    break;
                }
                else
                {
                    MessageBox.Show("Setiap kata harus terdiri atas 5 huruf. Silakan input ulang!");
                    break;
                }
            }

            if (cek == true)
            {
                panel_Words.Visible = false;
                panel_AfterPlay.Visible = true;

                Random rndIndex = new Random();

                int ind = rndIndex.Next(0, 5);

                lb_secretWord.Text = words[ind];

                foreach (char letter in words[ind])
                {
                    letters.Add(letter);
                }
            }
        }

        private void panel_AfterPlay_Paint(object sender, PaintEventArgs e)
        {
            lb_Huruf1.Text = display[0].ToString().ToUpper();
            lb_Huruf2.Text = display[1].ToString().ToUpper();
            lb_Huruf3.Text = display[2].ToString().ToUpper();
            lb_Huruf4.Text = display[3].ToString().ToUpper();
            lb_Huruf5.Text = display[4].ToString().ToUpper();
        }

        private void CekLetter(char tebakLetter)
        {
            if (letters.Contains(tebakLetter))
            {
                for (int i = 0; i < letters.Count; i++)
                {
                    if (letters[i] == tebakLetter)
                    {
                        display[i] = tebakLetter;
                    }
                }
            }

            panel_AfterPlay.Refresh();

            if (!display.Contains('_'))
            {
                MessageBox.Show("You Win");
            }
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'a';
            CekLetter(tebakLetter);
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'b';
            CekLetter(tebakLetter);
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'c';
            CekLetter(tebakLetter);
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'd';
            CekLetter(tebakLetter);
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'e';
            CekLetter(tebakLetter);
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'f';
            CekLetter(tebakLetter);
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'g';
            CekLetter(tebakLetter);
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'h';
            CekLetter(tebakLetter);
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'i';
            CekLetter(tebakLetter);
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'j';
            CekLetter(tebakLetter);
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'k';
            CekLetter(tebakLetter);
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'l';
            CekLetter(tebakLetter);
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'm';
            CekLetter(tebakLetter);
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'n';
            CekLetter(tebakLetter);
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'o';
            CekLetter(tebakLetter);
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'p';
            CekLetter(tebakLetter);
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'q';
            CekLetter(tebakLetter);
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'r';
            CekLetter(tebakLetter);
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            char tebakLetter = 's';
            CekLetter(tebakLetter);
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            char tebakLetter = 't';
            CekLetter(tebakLetter);
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'u';
            CekLetter(tebakLetter);
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'v';
            CekLetter(tebakLetter);
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'w';
            CekLetter(tebakLetter);
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'x';
            CekLetter(tebakLetter);
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'y';
            CekLetter(tebakLetter);
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            char tebakLetter = 'z';
            CekLetter(tebakLetter);
        }
    }
}
