﻿namespace TH02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Play = new System.Windows.Forms.Button();
            this.lb_Word1 = new System.Windows.Forms.Label();
            this.lb_Word2 = new System.Windows.Forms.Label();
            this.lb_Word3 = new System.Windows.Forms.Label();
            this.lb_Word4 = new System.Windows.Forms.Label();
            this.lb_Word5 = new System.Windows.Forms.Label();
            this.tBox_Word1 = new System.Windows.Forms.TextBox();
            this.tBox_Word2 = new System.Windows.Forms.TextBox();
            this.tBox_Word3 = new System.Windows.Forms.TextBox();
            this.tBox_Word4 = new System.Windows.Forms.TextBox();
            this.tBox_Word5 = new System.Windows.Forms.TextBox();
            this.panel_Words = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.lb_secretWord = new System.Windows.Forms.Label();
            this.lb_Huruf1 = new System.Windows.Forms.Label();
            this.lb_Huruf2 = new System.Windows.Forms.Label();
            this.lb_Huruf3 = new System.Windows.Forms.Label();
            this.lb_Huruf4 = new System.Windows.Forms.Label();
            this.lb_Huruf5 = new System.Windows.Forms.Label();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_Q = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_Z = new System.Windows.Forms.Button();
            this.panel_AfterPlay = new System.Windows.Forms.Panel();
            this.panel_Words.SuspendLayout();
            this.panel_AfterPlay.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Play
            // 
            this.btn_Play.Location = new System.Drawing.Point(131, 294);
            this.btn_Play.Name = "btn_Play";
            this.btn_Play.Size = new System.Drawing.Size(97, 47);
            this.btn_Play.TabIndex = 11;
            this.btn_Play.Text = "Play";
            this.btn_Play.UseVisualStyleBackColor = true;
            this.btn_Play.Click += new System.EventHandler(this.btn_Play_Click);
            // 
            // lb_Word1
            // 
            this.lb_Word1.AutoSize = true;
            this.lb_Word1.Location = new System.Drawing.Point(17, 15);
            this.lb_Word1.Name = "lb_Word1";
            this.lb_Word1.Size = new System.Drawing.Size(81, 25);
            this.lb_Word1.TabIndex = 0;
            this.lb_Word1.Text = "Word 1";
            // 
            // lb_Word2
            // 
            this.lb_Word2.AutoSize = true;
            this.lb_Word2.Location = new System.Drawing.Point(17, 65);
            this.lb_Word2.Name = "lb_Word2";
            this.lb_Word2.Size = new System.Drawing.Size(81, 25);
            this.lb_Word2.TabIndex = 1;
            this.lb_Word2.Text = "Word 2";
            // 
            // lb_Word3
            // 
            this.lb_Word3.AutoSize = true;
            this.lb_Word3.Location = new System.Drawing.Point(17, 118);
            this.lb_Word3.Name = "lb_Word3";
            this.lb_Word3.Size = new System.Drawing.Size(81, 25);
            this.lb_Word3.TabIndex = 2;
            this.lb_Word3.Text = "Word 3";
            // 
            // lb_Word4
            // 
            this.lb_Word4.AutoSize = true;
            this.lb_Word4.Location = new System.Drawing.Point(17, 171);
            this.lb_Word4.Name = "lb_Word4";
            this.lb_Word4.Size = new System.Drawing.Size(81, 25);
            this.lb_Word4.TabIndex = 3;
            this.lb_Word4.Text = "Word 4";
            // 
            // lb_Word5
            // 
            this.lb_Word5.AutoSize = true;
            this.lb_Word5.Location = new System.Drawing.Point(17, 226);
            this.lb_Word5.Name = "lb_Word5";
            this.lb_Word5.Size = new System.Drawing.Size(81, 25);
            this.lb_Word5.TabIndex = 4;
            this.lb_Word5.Text = "Word 5";
            // 
            // tBox_Word1
            // 
            this.tBox_Word1.Location = new System.Drawing.Point(128, 12);
            this.tBox_Word1.Name = "tBox_Word1";
            this.tBox_Word1.Size = new System.Drawing.Size(100, 31);
            this.tBox_Word1.TabIndex = 5;
            // 
            // tBox_Word2
            // 
            this.tBox_Word2.Location = new System.Drawing.Point(128, 62);
            this.tBox_Word2.Name = "tBox_Word2";
            this.tBox_Word2.Size = new System.Drawing.Size(100, 31);
            this.tBox_Word2.TabIndex = 6;
            // 
            // tBox_Word3
            // 
            this.tBox_Word3.Location = new System.Drawing.Point(128, 115);
            this.tBox_Word3.Name = "tBox_Word3";
            this.tBox_Word3.Size = new System.Drawing.Size(100, 31);
            this.tBox_Word3.TabIndex = 7;
            // 
            // tBox_Word4
            // 
            this.tBox_Word4.Location = new System.Drawing.Point(128, 168);
            this.tBox_Word4.Name = "tBox_Word4";
            this.tBox_Word4.Size = new System.Drawing.Size(100, 31);
            this.tBox_Word4.TabIndex = 8;
            // 
            // tBox_Word5
            // 
            this.tBox_Word5.Location = new System.Drawing.Point(128, 223);
            this.tBox_Word5.Name = "tBox_Word5";
            this.tBox_Word5.Size = new System.Drawing.Size(100, 31);
            this.tBox_Word5.TabIndex = 9;
            // 
            // panel_Words
            // 
            this.panel_Words.Controls.Add(this.button1);
            this.panel_Words.Controls.Add(this.btn_Play);
            this.panel_Words.Controls.Add(this.tBox_Word5);
            this.panel_Words.Controls.Add(this.lb_Word5);
            this.panel_Words.Controls.Add(this.tBox_Word4);
            this.panel_Words.Controls.Add(this.tBox_Word3);
            this.panel_Words.Controls.Add(this.lb_Word4);
            this.panel_Words.Controls.Add(this.lb_Word1);
            this.panel_Words.Controls.Add(this.tBox_Word2);
            this.panel_Words.Controls.Add(this.tBox_Word1);
            this.panel_Words.Controls.Add(this.lb_Word3);
            this.panel_Words.Controls.Add(this.lb_Word2);
            this.panel_Words.Location = new System.Drawing.Point(62, 70);
            this.panel_Words.Name = "panel_Words";
            this.panel_Words.Size = new System.Drawing.Size(249, 344);
            this.panel_Words.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(257, 158);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 93);
            this.button1.TabIndex = 20;
            this.button1.Text = "W";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btn_W
            // 
            this.btn_W.Location = new System.Drawing.Point(126, 203);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(94, 93);
            this.btn_W.TabIndex = 19;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = true;
            this.btn_W.Click += new System.EventHandler(this.btn_W_Click);
            // 
            // lb_secretWord
            // 
            this.lb_secretWord.AutoSize = true;
            this.lb_secretWord.Location = new System.Drawing.Point(927, 16);
            this.lb_secretWord.Name = "lb_secretWord";
            this.lb_secretWord.Size = new System.Drawing.Size(30, 25);
            this.lb_secretWord.TabIndex = 13;
            this.lb_secretWord.Text = "...";
            // 
            // lb_Huruf1
            // 
            this.lb_Huruf1.AutoSize = true;
            this.lb_Huruf1.Location = new System.Drawing.Point(322, 16);
            this.lb_Huruf1.Name = "lb_Huruf1";
            this.lb_Huruf1.Size = new System.Drawing.Size(24, 25);
            this.lb_Huruf1.TabIndex = 14;
            this.lb_Huruf1.Text = "_";
            this.lb_Huruf1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lb_Huruf2
            // 
            this.lb_Huruf2.AutoSize = true;
            this.lb_Huruf2.Location = new System.Drawing.Point(425, 16);
            this.lb_Huruf2.Name = "lb_Huruf2";
            this.lb_Huruf2.Size = new System.Drawing.Size(24, 25);
            this.lb_Huruf2.TabIndex = 15;
            this.lb_Huruf2.Text = "_";
            this.lb_Huruf2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lb_Huruf3
            // 
            this.lb_Huruf3.AutoSize = true;
            this.lb_Huruf3.Location = new System.Drawing.Point(526, 16);
            this.lb_Huruf3.Name = "lb_Huruf3";
            this.lb_Huruf3.Size = new System.Drawing.Size(24, 25);
            this.lb_Huruf3.TabIndex = 16;
            this.lb_Huruf3.Text = "_";
            this.lb_Huruf3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lb_Huruf4
            // 
            this.lb_Huruf4.AutoSize = true;
            this.lb_Huruf4.Location = new System.Drawing.Point(626, 16);
            this.lb_Huruf4.Name = "lb_Huruf4";
            this.lb_Huruf4.Size = new System.Drawing.Size(24, 25);
            this.lb_Huruf4.TabIndex = 17;
            this.lb_Huruf4.Text = "_";
            this.lb_Huruf4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lb_Huruf5
            // 
            this.lb_Huruf5.AutoSize = true;
            this.lb_Huruf5.Location = new System.Drawing.Point(725, 16);
            this.lb_Huruf5.Name = "lb_Huruf5";
            this.lb_Huruf5.Size = new System.Drawing.Size(24, 25);
            this.lb_Huruf5.TabIndex = 18;
            this.lb_Huruf5.Text = "_";
            this.lb_Huruf5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_E
            // 
            this.btn_E.Location = new System.Drawing.Point(234, 203);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(94, 93);
            this.btn_E.TabIndex = 21;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.btn_E_Click);
            // 
            // btn_R
            // 
            this.btn_R.Location = new System.Drawing.Point(345, 203);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(94, 93);
            this.btn_R.TabIndex = 22;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = true;
            this.btn_R.Click += new System.EventHandler(this.btn_R_Click);
            // 
            // btn_T
            // 
            this.btn_T.Location = new System.Drawing.Point(456, 203);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(94, 93);
            this.btn_T.TabIndex = 23;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = true;
            this.btn_T.Click += new System.EventHandler(this.btn_T_Click);
            // 
            // btn_Y
            // 
            this.btn_Y.Location = new System.Drawing.Point(566, 203);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(94, 93);
            this.btn_Y.TabIndex = 24;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = true;
            this.btn_Y.Click += new System.EventHandler(this.btn_Y_Click);
            // 
            // btn_U
            // 
            this.btn_U.Location = new System.Drawing.Point(676, 203);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(94, 93);
            this.btn_U.TabIndex = 25;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = true;
            this.btn_U.Click += new System.EventHandler(this.btn_U_Click);
            // 
            // btn_I
            // 
            this.btn_I.Location = new System.Drawing.Point(787, 203);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(94, 93);
            this.btn_I.TabIndex = 26;
            this.btn_I.Text = "I";
            this.btn_I.UseVisualStyleBackColor = true;
            this.btn_I.Click += new System.EventHandler(this.btn_I_Click);
            // 
            // btn_O
            // 
            this.btn_O.Location = new System.Drawing.Point(900, 203);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(94, 93);
            this.btn_O.TabIndex = 27;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = true;
            this.btn_O.Click += new System.EventHandler(this.btn_O_Click);
            // 
            // btn_P
            // 
            this.btn_P.Location = new System.Drawing.Point(1011, 203);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(94, 93);
            this.btn_P.TabIndex = 28;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.btn_P_Click);
            // 
            // btn_Q
            // 
            this.btn_Q.Location = new System.Drawing.Point(15, 203);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(94, 93);
            this.btn_Q.TabIndex = 29;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = true;
            this.btn_Q.Click += new System.EventHandler(this.btn_Q_Click);
            // 
            // btn_L
            // 
            this.btn_L.Location = new System.Drawing.Point(958, 316);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(94, 93);
            this.btn_L.TabIndex = 38;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = true;
            this.btn_L.Click += new System.EventHandler(this.btn_L_Click);
            // 
            // btn_A
            // 
            this.btn_A.Location = new System.Drawing.Point(69, 316);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(94, 93);
            this.btn_A.TabIndex = 30;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.btn_A_Click);
            // 
            // btn_K
            // 
            this.btn_K.Location = new System.Drawing.Point(847, 316);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(94, 93);
            this.btn_K.TabIndex = 37;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = true;
            this.btn_K.Click += new System.EventHandler(this.btn_K_Click);
            // 
            // btn_J
            // 
            this.btn_J.Location = new System.Drawing.Point(734, 316);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(94, 93);
            this.btn_J.TabIndex = 36;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = true;
            this.btn_J.Click += new System.EventHandler(this.btn_J_Click);
            // 
            // btn_H
            // 
            this.btn_H.Location = new System.Drawing.Point(623, 316);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(94, 93);
            this.btn_H.TabIndex = 35;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = true;
            this.btn_H.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_G
            // 
            this.btn_G.Location = new System.Drawing.Point(513, 316);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(94, 93);
            this.btn_G.TabIndex = 34;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = true;
            this.btn_G.Click += new System.EventHandler(this.btn_G_Click);
            // 
            // btn_F
            // 
            this.btn_F.Location = new System.Drawing.Point(403, 316);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(94, 93);
            this.btn_F.TabIndex = 33;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = true;
            this.btn_F.Click += new System.EventHandler(this.btn_F_Click);
            // 
            // btn_D
            // 
            this.btn_D.Location = new System.Drawing.Point(292, 316);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(94, 93);
            this.btn_D.TabIndex = 32;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = true;
            this.btn_D.Click += new System.EventHandler(this.btn_D_Click);
            // 
            // btn_S
            // 
            this.btn_S.Location = new System.Drawing.Point(181, 316);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(94, 93);
            this.btn_S.TabIndex = 31;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = true;
            this.btn_S.Click += new System.EventHandler(this.btn_S_Click);
            // 
            // btn_M
            // 
            this.btn_M.Location = new System.Drawing.Point(847, 431);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(94, 93);
            this.btn_M.TabIndex = 45;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = true;
            this.btn_M.Click += new System.EventHandler(this.btn_M_Click);
            // 
            // btn_N
            // 
            this.btn_N.Location = new System.Drawing.Point(734, 431);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(94, 93);
            this.btn_N.TabIndex = 44;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = true;
            this.btn_N.Click += new System.EventHandler(this.btn_N_Click);
            // 
            // btn_B
            // 
            this.btn_B.Location = new System.Drawing.Point(623, 431);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(94, 93);
            this.btn_B.TabIndex = 43;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = true;
            this.btn_B.Click += new System.EventHandler(this.btn_B_Click);
            // 
            // btn_V
            // 
            this.btn_V.Location = new System.Drawing.Point(513, 431);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(94, 93);
            this.btn_V.TabIndex = 42;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = true;
            this.btn_V.Click += new System.EventHandler(this.btn_V_Click);
            // 
            // btn_C
            // 
            this.btn_C.Location = new System.Drawing.Point(403, 431);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(94, 93);
            this.btn_C.TabIndex = 41;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // btn_X
            // 
            this.btn_X.Location = new System.Drawing.Point(292, 431);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(94, 93);
            this.btn_X.TabIndex = 40;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = true;
            this.btn_X.Click += new System.EventHandler(this.btn_X_Click);
            // 
            // btn_Z
            // 
            this.btn_Z.Location = new System.Drawing.Point(181, 431);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(94, 93);
            this.btn_Z.TabIndex = 39;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = true;
            this.btn_Z.Click += new System.EventHandler(this.btn_Z_Click);
            // 
            // panel_AfterPlay
            // 
            this.panel_AfterPlay.Controls.Add(this.btn_Q);
            this.panel_AfterPlay.Controls.Add(this.btn_M);
            this.panel_AfterPlay.Controls.Add(this.btn_N);
            this.panel_AfterPlay.Controls.Add(this.btn_B);
            this.panel_AfterPlay.Controls.Add(this.btn_V);
            this.panel_AfterPlay.Controls.Add(this.btn_C);
            this.panel_AfterPlay.Controls.Add(this.btn_X);
            this.panel_AfterPlay.Controls.Add(this.btn_Z);
            this.panel_AfterPlay.Controls.Add(this.btn_P);
            this.panel_AfterPlay.Controls.Add(this.btn_L);
            this.panel_AfterPlay.Controls.Add(this.btn_W);
            this.panel_AfterPlay.Controls.Add(this.btn_A);
            this.panel_AfterPlay.Controls.Add(this.btn_O);
            this.panel_AfterPlay.Controls.Add(this.btn_K);
            this.panel_AfterPlay.Controls.Add(this.btn_I);
            this.panel_AfterPlay.Controls.Add(this.btn_J);
            this.panel_AfterPlay.Controls.Add(this.btn_U);
            this.panel_AfterPlay.Controls.Add(this.btn_H);
            this.panel_AfterPlay.Controls.Add(this.btn_Y);
            this.panel_AfterPlay.Controls.Add(this.btn_G);
            this.panel_AfterPlay.Controls.Add(this.btn_T);
            this.panel_AfterPlay.Controls.Add(this.btn_F);
            this.panel_AfterPlay.Controls.Add(this.btn_D);
            this.panel_AfterPlay.Controls.Add(this.btn_R);
            this.panel_AfterPlay.Controls.Add(this.btn_S);
            this.panel_AfterPlay.Controls.Add(this.btn_E);
            this.panel_AfterPlay.Controls.Add(this.lb_Huruf5);
            this.panel_AfterPlay.Controls.Add(this.lb_Huruf4);
            this.panel_AfterPlay.Controls.Add(this.lb_Huruf3);
            this.panel_AfterPlay.Controls.Add(this.lb_Huruf2);
            this.panel_AfterPlay.Controls.Add(this.lb_Huruf1);
            this.panel_AfterPlay.Controls.Add(this.lb_secretWord);
            this.panel_AfterPlay.Location = new System.Drawing.Point(166, 45);
            this.panel_AfterPlay.Name = "panel_AfterPlay";
            this.panel_AfterPlay.Size = new System.Drawing.Size(1134, 553);
            this.panel_AfterPlay.TabIndex = 46;
            this.panel_AfterPlay.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_AfterPlay_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1565, 758);
            this.Controls.Add(this.panel_Words);
            this.Controls.Add(this.panel_AfterPlay);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_Words.ResumeLayout(false);
            this.panel_Words.PerformLayout();
            this.panel_AfterPlay.ResumeLayout(false);
            this.panel_AfterPlay.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btn_Play;
        private System.Windows.Forms.Label lb_Word1;
        private System.Windows.Forms.Label lb_Word2;
        private System.Windows.Forms.Label lb_Word3;
        private System.Windows.Forms.Label lb_Word4;
        private System.Windows.Forms.Label lb_Word5;
        private System.Windows.Forms.TextBox tBox_Word1;
        private System.Windows.Forms.TextBox tBox_Word2;
        private System.Windows.Forms.TextBox tBox_Word3;
        private System.Windows.Forms.TextBox tBox_Word4;
        private System.Windows.Forms.TextBox tBox_Word5;
        private System.Windows.Forms.Panel panel_Words;
        private System.Windows.Forms.Label lb_secretWord;
        private System.Windows.Forms.Label lb_Huruf1;
        private System.Windows.Forms.Label lb_Huruf2;
        private System.Windows.Forms.Label lb_Huruf3;
        private System.Windows.Forms.Label lb_Huruf4;
        private System.Windows.Forms.Label lb_Huruf5;
        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Panel panel_AfterPlay;
    }
}

