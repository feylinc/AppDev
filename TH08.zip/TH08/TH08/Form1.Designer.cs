﻿namespace TH08
{
    partial class form_uniqme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_tabel = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tBox_subTotal = new System.Windows.Forms.TextBox();
            this.tBox_total = new System.Windows.Forms.TextBox();
            this.pBox_tShirt1 = new System.Windows.Forms.PictureBox();
            this.pBox_tShirt2 = new System.Windows.Forms.PictureBox();
            this.pBox_tShirt3 = new System.Windows.Forms.PictureBox();
            this.lb_tShirt1 = new System.Windows.Forms.Label();
            this.lb_tShirt2 = new System.Windows.Forms.Label();
            this.lb_tShirt3 = new System.Windows.Forms.Label();
            this.lb_hargaTShirt1 = new System.Windows.Forms.Label();
            this.lb_hargaTShirt2 = new System.Windows.Forms.Label();
            this.lb_hargaTShirt3 = new System.Windows.Forms.Label();
            this.btn_addTShirt1 = new System.Windows.Forms.Button();
            this.btn_addTShirt2 = new System.Windows.Forms.Button();
            this.btn_addTShirt3 = new System.Windows.Forms.Button();
            this.panel_tShirt = new System.Windows.Forms.Panel();
            this.panel_shirt = new System.Windows.Forms.Panel();
            this.btn_addShirt3 = new System.Windows.Forms.Button();
            this.btn_addShirt2 = new System.Windows.Forms.Button();
            this.btn_addShirt1 = new System.Windows.Forms.Button();
            this.lb_hargaShirt3 = new System.Windows.Forms.Label();
            this.lb_hargaShirt2 = new System.Windows.Forms.Label();
            this.lb_hargaShirt1 = new System.Windows.Forms.Label();
            this.lb_shirt3 = new System.Windows.Forms.Label();
            this.lb_shirt2 = new System.Windows.Forms.Label();
            this.lb_shirt1 = new System.Windows.Forms.Label();
            this.pBox_shirt3 = new System.Windows.Forms.PictureBox();
            this.pBox_shirt2 = new System.Windows.Forms.PictureBox();
            this.pBox_shirt1 = new System.Windows.Forms.PictureBox();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.btn_addPants3 = new System.Windows.Forms.Button();
            this.btn_addPants2 = new System.Windows.Forms.Button();
            this.btn_addPants1 = new System.Windows.Forms.Button();
            this.lb_hargaPants3 = new System.Windows.Forms.Label();
            this.lb_hargaPants2 = new System.Windows.Forms.Label();
            this.lb_hargaPants1 = new System.Windows.Forms.Label();
            this.lb_pants3 = new System.Windows.Forms.Label();
            this.lb_pants2 = new System.Windows.Forms.Label();
            this.lb_pants1 = new System.Windows.Forms.Label();
            this.pBox_pants3 = new System.Windows.Forms.PictureBox();
            this.pBox_pants2 = new System.Windows.Forms.PictureBox();
            this.pBox_pants1 = new System.Windows.Forms.PictureBox();
            this.panel_longPants = new System.Windows.Forms.Panel();
            this.btn_addLongPants3 = new System.Windows.Forms.Button();
            this.btn_addLongPants2 = new System.Windows.Forms.Button();
            this.btn_addLongPants1 = new System.Windows.Forms.Button();
            this.lb_hargaLongPants3 = new System.Windows.Forms.Label();
            this.lb_hargaLongPants2 = new System.Windows.Forms.Label();
            this.lb_hargaLongPants1 = new System.Windows.Forms.Label();
            this.lb_longPants3 = new System.Windows.Forms.Label();
            this.lb_longPants2 = new System.Windows.Forms.Label();
            this.lb_longPants1 = new System.Windows.Forms.Label();
            this.pBox_longPants3 = new System.Windows.Forms.PictureBox();
            this.pBox_longPants2 = new System.Windows.Forms.PictureBox();
            this.pBox_longPants1 = new System.Windows.Forms.PictureBox();
            this.panel_shoes = new System.Windows.Forms.Panel();
            this.btn_addShoes3 = new System.Windows.Forms.Button();
            this.btn_addShoes2 = new System.Windows.Forms.Button();
            this.btn_addShoes1 = new System.Windows.Forms.Button();
            this.lb_hargaShoes3 = new System.Windows.Forms.Label();
            this.lb_hargaShoes2 = new System.Windows.Forms.Label();
            this.lb_hargaShoes1 = new System.Windows.Forms.Label();
            this.lb_shoes3 = new System.Windows.Forms.Label();
            this.lb_shoes2 = new System.Windows.Forms.Label();
            this.lb_shoes1 = new System.Windows.Forms.Label();
            this.pBox_shoes3 = new System.Windows.Forms.PictureBox();
            this.pBox_shoes2 = new System.Windows.Forms.PictureBox();
            this.pBox_shoes1 = new System.Windows.Forms.PictureBox();
            this.panel_jewel = new System.Windows.Forms.Panel();
            this.btn_addJewel3 = new System.Windows.Forms.Button();
            this.btn_addJewel2 = new System.Windows.Forms.Button();
            this.btn_addJewel1 = new System.Windows.Forms.Button();
            this.lb_hargaJewel3 = new System.Windows.Forms.Label();
            this.lb_hargaJewel2 = new System.Windows.Forms.Label();
            this.lb_hargaJewel1 = new System.Windows.Forms.Label();
            this.lb_jewel3 = new System.Windows.Forms.Label();
            this.lb_jewel2 = new System.Windows.Forms.Label();
            this.lb_jewel1 = new System.Windows.Forms.Label();
            this.pBox_jewel3 = new System.Windows.Forms.PictureBox();
            this.pBox_jewel2 = new System.Windows.Forms.PictureBox();
            this.pBox_jewel1 = new System.Windows.Forms.PictureBox();
            this.lb_uploadImage = new System.Windows.Forms.Label();
            this.btn_upload = new System.Windows.Forms.Button();
            this.pBox_others = new System.Windows.Forms.PictureBox();
            this.lb_itemName = new System.Windows.Forms.Label();
            this.lb_itemPrice = new System.Windows.Forms.Label();
            this.tBox_itemName = new System.Windows.Forms.TextBox();
            this.tBox_itemPrice = new System.Windows.Forms.TextBox();
            this.btn_addOthers = new System.Windows.Forms.Button();
            this.panel_others = new System.Windows.Forms.Panel();
            this.btn_delete = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_tabel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_tShirt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_tShirt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_tShirt3)).BeginInit();
            this.panel_tShirt.SuspendLayout();
            this.panel_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shirt3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shirt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shirt1)).BeginInit();
            this.panel_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_pants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_pants2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_pants1)).BeginInit();
            this.panel_longPants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_longPants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_longPants2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_longPants1)).BeginInit();
            this.panel_shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shoes3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shoes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shoes1)).BeginInit();
            this.panel_jewel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_jewel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_jewel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_jewel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_others)).BeginInit();
            this.panel_others.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1587, 40);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(134, 36);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(219, 44);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(219, 44);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(174, 36);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(263, 44);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(263, 44);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(155, 36);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(261, 44);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(261, 44);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(105, 36);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv_tabel
            // 
            this.dgv_tabel.AllowUserToAddRows = false;
            this.dgv_tabel.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_tabel.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_tabel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_tabel.Location = new System.Drawing.Point(840, 68);
            this.dgv_tabel.MultiSelect = false;
            this.dgv_tabel.Name = "dgv_tabel";
            this.dgv_tabel.ReadOnly = true;
            this.dgv_tabel.RowHeadersVisible = false;
            this.dgv_tabel.RowHeadersWidth = 82;
            this.dgv_tabel.RowTemplate.Height = 33;
            this.dgv_tabel.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_tabel.Size = new System.Drawing.Size(717, 530);
            this.dgv_tabel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(833, 625);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 42);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sub-Total: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(916, 703);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 42);
            this.label2.TabIndex = 3;
            this.label2.Text = "Total: ";
            // 
            // tBox_subTotal
            // 
            this.tBox_subTotal.Location = new System.Drawing.Point(1035, 636);
            this.tBox_subTotal.Name = "tBox_subTotal";
            this.tBox_subTotal.Size = new System.Drawing.Size(263, 31);
            this.tBox_subTotal.TabIndex = 4;
            // 
            // tBox_total
            // 
            this.tBox_total.Location = new System.Drawing.Point(1035, 714);
            this.tBox_total.Name = "tBox_total";
            this.tBox_total.Size = new System.Drawing.Size(263, 31);
            this.tBox_total.TabIndex = 5;
            // 
            // pBox_tShirt1
            // 
            this.pBox_tShirt1.Image = global::TH08.Properties.Resources.T_Shirt_Kerah_Bulat;
            this.pBox_tShirt1.Location = new System.Drawing.Point(12, 13);
            this.pBox_tShirt1.Name = "pBox_tShirt1";
            this.pBox_tShirt1.Size = new System.Drawing.Size(203, 203);
            this.pBox_tShirt1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_tShirt1.TabIndex = 6;
            this.pBox_tShirt1.TabStop = false;
            // 
            // pBox_tShirt2
            // 
            this.pBox_tShirt2.Image = global::TH08.Properties.Resources.AIRism_T_Shirt;
            this.pBox_tShirt2.Location = new System.Drawing.Point(278, 13);
            this.pBox_tShirt2.Name = "pBox_tShirt2";
            this.pBox_tShirt2.Size = new System.Drawing.Size(203, 203);
            this.pBox_tShirt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_tShirt2.TabIndex = 7;
            this.pBox_tShirt2.TabStop = false;
            // 
            // pBox_tShirt3
            // 
            this.pBox_tShirt3.Image = global::TH08.Properties.Resources.T_Shirt_VNeck;
            this.pBox_tShirt3.Location = new System.Drawing.Point(545, 13);
            this.pBox_tShirt3.Name = "pBox_tShirt3";
            this.pBox_tShirt3.Size = new System.Drawing.Size(203, 203);
            this.pBox_tShirt3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_tShirt3.TabIndex = 8;
            this.pBox_tShirt3.TabStop = false;
            // 
            // lb_tShirt1
            // 
            this.lb_tShirt1.AutoSize = true;
            this.lb_tShirt1.Location = new System.Drawing.Point(7, 231);
            this.lb_tShirt1.Name = "lb_tShirt1";
            this.lb_tShirt1.Size = new System.Drawing.Size(194, 25);
            this.lb_tShirt1.TabIndex = 9;
            this.lb_tShirt1.Text = "T-Shirt Kerah Bulat";
            // 
            // lb_tShirt2
            // 
            this.lb_tShirt2.AutoSize = true;
            this.lb_tShirt2.Location = new System.Drawing.Point(273, 231);
            this.lb_tShirt2.Name = "lb_tShirt2";
            this.lb_tShirt2.Size = new System.Drawing.Size(149, 25);
            this.lb_tShirt2.TabIndex = 10;
            this.lb_tShirt2.Text = "AIRism T-Shirt";
            // 
            // lb_tShirt3
            // 
            this.lb_tShirt3.AutoSize = true;
            this.lb_tShirt3.Location = new System.Drawing.Point(540, 231);
            this.lb_tShirt3.Name = "lb_tShirt3";
            this.lb_tShirt3.Size = new System.Drawing.Size(145, 25);
            this.lb_tShirt3.TabIndex = 11;
            this.lb_tShirt3.Text = "T-Shirt VNeck";
            // 
            // lb_hargaTShirt1
            // 
            this.lb_hargaTShirt1.AutoSize = true;
            this.lb_hargaTShirt1.Location = new System.Drawing.Point(7, 269);
            this.lb_hargaTShirt1.Name = "lb_hargaTShirt1";
            this.lb_hargaTShirt1.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaTShirt1.TabIndex = 12;
            this.lb_hargaTShirt1.Text = "Rp120,000.00";
            // 
            // lb_hargaTShirt2
            // 
            this.lb_hargaTShirt2.AutoSize = true;
            this.lb_hargaTShirt2.Location = new System.Drawing.Point(273, 269);
            this.lb_hargaTShirt2.Name = "lb_hargaTShirt2";
            this.lb_hargaTShirt2.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaTShirt2.TabIndex = 13;
            this.lb_hargaTShirt2.Text = "Rp150,000.00";
            // 
            // lb_hargaTShirt3
            // 
            this.lb_hargaTShirt3.AutoSize = true;
            this.lb_hargaTShirt3.Location = new System.Drawing.Point(540, 269);
            this.lb_hargaTShirt3.Name = "lb_hargaTShirt3";
            this.lb_hargaTShirt3.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaTShirt3.TabIndex = 14;
            this.lb_hargaTShirt3.Text = "Rp170,000.00";
            // 
            // btn_addTShirt1
            // 
            this.btn_addTShirt1.Location = new System.Drawing.Point(12, 320);
            this.btn_addTShirt1.Name = "btn_addTShirt1";
            this.btn_addTShirt1.Size = new System.Drawing.Size(142, 38);
            this.btn_addTShirt1.TabIndex = 15;
            this.btn_addTShirt1.Text = "Add to Cart";
            this.btn_addTShirt1.UseVisualStyleBackColor = true;
            this.btn_addTShirt1.Click += new System.EventHandler(this.btn_addTShirt1_Click);
            // 
            // btn_addTShirt2
            // 
            this.btn_addTShirt2.Location = new System.Drawing.Point(278, 320);
            this.btn_addTShirt2.Name = "btn_addTShirt2";
            this.btn_addTShirt2.Size = new System.Drawing.Size(142, 38);
            this.btn_addTShirt2.TabIndex = 16;
            this.btn_addTShirt2.Text = "Add to Cart";
            this.btn_addTShirt2.UseVisualStyleBackColor = true;
            this.btn_addTShirt2.Click += new System.EventHandler(this.btn_addTShirt2_Click);
            // 
            // btn_addTShirt3
            // 
            this.btn_addTShirt3.Location = new System.Drawing.Point(545, 320);
            this.btn_addTShirt3.Name = "btn_addTShirt3";
            this.btn_addTShirt3.Size = new System.Drawing.Size(142, 38);
            this.btn_addTShirt3.TabIndex = 17;
            this.btn_addTShirt3.Text = "Add to Cart";
            this.btn_addTShirt3.UseVisualStyleBackColor = true;
            this.btn_addTShirt3.Click += new System.EventHandler(this.btn_addTShirt3_Click);
            // 
            // panel_tShirt
            // 
            this.panel_tShirt.Controls.Add(this.btn_addTShirt3);
            this.panel_tShirt.Controls.Add(this.btn_addTShirt2);
            this.panel_tShirt.Controls.Add(this.btn_addTShirt1);
            this.panel_tShirt.Controls.Add(this.lb_hargaTShirt3);
            this.panel_tShirt.Controls.Add(this.lb_hargaTShirt2);
            this.panel_tShirt.Controls.Add(this.lb_hargaTShirt1);
            this.panel_tShirt.Controls.Add(this.lb_tShirt3);
            this.panel_tShirt.Controls.Add(this.lb_tShirt2);
            this.panel_tShirt.Controls.Add(this.lb_tShirt1);
            this.panel_tShirt.Controls.Add(this.pBox_tShirt3);
            this.panel_tShirt.Controls.Add(this.pBox_tShirt2);
            this.panel_tShirt.Controls.Add(this.pBox_tShirt1);
            this.panel_tShirt.Location = new System.Drawing.Point(21, 55);
            this.panel_tShirt.Name = "panel_tShirt";
            this.panel_tShirt.Size = new System.Drawing.Size(762, 373);
            this.panel_tShirt.TabIndex = 18;
            // 
            // panel_shirt
            // 
            this.panel_shirt.Controls.Add(this.btn_addShirt3);
            this.panel_shirt.Controls.Add(this.btn_addShirt2);
            this.panel_shirt.Controls.Add(this.btn_addShirt1);
            this.panel_shirt.Controls.Add(this.lb_hargaShirt3);
            this.panel_shirt.Controls.Add(this.lb_hargaShirt2);
            this.panel_shirt.Controls.Add(this.lb_hargaShirt1);
            this.panel_shirt.Controls.Add(this.lb_shirt3);
            this.panel_shirt.Controls.Add(this.lb_shirt2);
            this.panel_shirt.Controls.Add(this.lb_shirt1);
            this.panel_shirt.Controls.Add(this.pBox_shirt3);
            this.panel_shirt.Controls.Add(this.pBox_shirt2);
            this.panel_shirt.Controls.Add(this.pBox_shirt1);
            this.panel_shirt.Location = new System.Drawing.Point(21, 55);
            this.panel_shirt.Name = "panel_shirt";
            this.panel_shirt.Size = new System.Drawing.Size(762, 373);
            this.panel_shirt.TabIndex = 19;
            // 
            // btn_addShirt3
            // 
            this.btn_addShirt3.Location = new System.Drawing.Point(545, 320);
            this.btn_addShirt3.Name = "btn_addShirt3";
            this.btn_addShirt3.Size = new System.Drawing.Size(142, 38);
            this.btn_addShirt3.TabIndex = 17;
            this.btn_addShirt3.Text = "Add to Cart";
            this.btn_addShirt3.UseVisualStyleBackColor = true;
            this.btn_addShirt3.Click += new System.EventHandler(this.btn_addShirt3_Click);
            // 
            // btn_addShirt2
            // 
            this.btn_addShirt2.Location = new System.Drawing.Point(278, 320);
            this.btn_addShirt2.Name = "btn_addShirt2";
            this.btn_addShirt2.Size = new System.Drawing.Size(142, 38);
            this.btn_addShirt2.TabIndex = 16;
            this.btn_addShirt2.Text = "Add to Cart";
            this.btn_addShirt2.UseVisualStyleBackColor = true;
            this.btn_addShirt2.Click += new System.EventHandler(this.btn_addShirt2_Click);
            // 
            // btn_addShirt1
            // 
            this.btn_addShirt1.Location = new System.Drawing.Point(12, 320);
            this.btn_addShirt1.Name = "btn_addShirt1";
            this.btn_addShirt1.Size = new System.Drawing.Size(142, 38);
            this.btn_addShirt1.TabIndex = 15;
            this.btn_addShirt1.Text = "Add to Cart";
            this.btn_addShirt1.UseVisualStyleBackColor = true;
            this.btn_addShirt1.Click += new System.EventHandler(this.btn_addShirt1_Click);
            // 
            // lb_hargaShirt3
            // 
            this.lb_hargaShirt3.AutoSize = true;
            this.lb_hargaShirt3.Location = new System.Drawing.Point(540, 269);
            this.lb_hargaShirt3.Name = "lb_hargaShirt3";
            this.lb_hargaShirt3.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaShirt3.TabIndex = 14;
            this.lb_hargaShirt3.Text = "Rp400,000.00";
            // 
            // lb_hargaShirt2
            // 
            this.lb_hargaShirt2.AutoSize = true;
            this.lb_hargaShirt2.Location = new System.Drawing.Point(273, 269);
            this.lb_hargaShirt2.Name = "lb_hargaShirt2";
            this.lb_hargaShirt2.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaShirt2.TabIndex = 13;
            this.lb_hargaShirt2.Text = "Rp350,000.00";
            // 
            // lb_hargaShirt1
            // 
            this.lb_hargaShirt1.AutoSize = true;
            this.lb_hargaShirt1.Location = new System.Drawing.Point(7, 269);
            this.lb_hargaShirt1.Name = "lb_hargaShirt1";
            this.lb_hargaShirt1.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaShirt1.TabIndex = 12;
            this.lb_hargaShirt1.Text = "Rp230,000.00";
            // 
            // lb_shirt3
            // 
            this.lb_shirt3.AutoSize = true;
            this.lb_shirt3.Location = new System.Drawing.Point(540, 231);
            this.lb_shirt3.Name = "lb_shirt3";
            this.lb_shirt3.Size = new System.Drawing.Size(182, 25);
            this.lb_shirt3.TabIndex = 11;
            this.lb_shirt3.Text = "Shirt Flanel Kotak";
            // 
            // lb_shirt2
            // 
            this.lb_shirt2.AutoSize = true;
            this.lb_shirt2.Location = new System.Drawing.Point(273, 231);
            this.lb_shirt2.Name = "lb_shirt2";
            this.lb_shirt2.Size = new System.Drawing.Size(187, 25);
            this.lb_shirt2.TabIndex = 10;
            this.lb_shirt2.Text = "Jaket Shirt Luaran";
            // 
            // lb_shirt1
            // 
            this.lb_shirt1.AutoSize = true;
            this.lb_shirt1.Location = new System.Drawing.Point(7, 231);
            this.lb_shirt1.Name = "lb_shirt1";
            this.lb_shirt1.Size = new System.Drawing.Size(181, 25);
            this.lb_shirt1.TabIndex = 9;
            this.lb_shirt1.Text = "Shirt Katun Kerah";
            // 
            // pBox_shirt3
            // 
            this.pBox_shirt3.Image = global::TH08.Properties.Resources.Shirt_Flanel_Kotak;
            this.pBox_shirt3.Location = new System.Drawing.Point(545, 13);
            this.pBox_shirt3.Name = "pBox_shirt3";
            this.pBox_shirt3.Size = new System.Drawing.Size(203, 203);
            this.pBox_shirt3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_shirt3.TabIndex = 8;
            this.pBox_shirt3.TabStop = false;
            // 
            // pBox_shirt2
            // 
            this.pBox_shirt2.Image = global::TH08.Properties.Resources.Jaket_Shirt_Luaran;
            this.pBox_shirt2.Location = new System.Drawing.Point(278, 13);
            this.pBox_shirt2.Name = "pBox_shirt2";
            this.pBox_shirt2.Size = new System.Drawing.Size(203, 203);
            this.pBox_shirt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_shirt2.TabIndex = 7;
            this.pBox_shirt2.TabStop = false;
            // 
            // pBox_shirt1
            // 
            this.pBox_shirt1.Image = global::TH08.Properties.Resources.Shirt_Katun_Kerah;
            this.pBox_shirt1.Location = new System.Drawing.Point(12, 13);
            this.pBox_shirt1.Name = "pBox_shirt1";
            this.pBox_shirt1.Size = new System.Drawing.Size(203, 203);
            this.pBox_shirt1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_shirt1.TabIndex = 6;
            this.pBox_shirt1.TabStop = false;
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.btn_addPants3);
            this.panel_pants.Controls.Add(this.btn_addPants2);
            this.panel_pants.Controls.Add(this.btn_addPants1);
            this.panel_pants.Controls.Add(this.lb_hargaPants3);
            this.panel_pants.Controls.Add(this.lb_hargaPants2);
            this.panel_pants.Controls.Add(this.lb_hargaPants1);
            this.panel_pants.Controls.Add(this.lb_pants3);
            this.panel_pants.Controls.Add(this.lb_pants2);
            this.panel_pants.Controls.Add(this.lb_pants1);
            this.panel_pants.Controls.Add(this.pBox_pants3);
            this.panel_pants.Controls.Add(this.pBox_pants2);
            this.panel_pants.Controls.Add(this.pBox_pants1);
            this.panel_pants.Location = new System.Drawing.Point(21, 55);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(762, 373);
            this.panel_pants.TabIndex = 20;
            // 
            // btn_addPants3
            // 
            this.btn_addPants3.Location = new System.Drawing.Point(545, 320);
            this.btn_addPants3.Name = "btn_addPants3";
            this.btn_addPants3.Size = new System.Drawing.Size(142, 38);
            this.btn_addPants3.TabIndex = 17;
            this.btn_addPants3.Text = "Add to Cart";
            this.btn_addPants3.UseVisualStyleBackColor = true;
            this.btn_addPants3.Click += new System.EventHandler(this.btn_addPants3_Click);
            // 
            // btn_addPants2
            // 
            this.btn_addPants2.Location = new System.Drawing.Point(278, 320);
            this.btn_addPants2.Name = "btn_addPants2";
            this.btn_addPants2.Size = new System.Drawing.Size(142, 38);
            this.btn_addPants2.TabIndex = 16;
            this.btn_addPants2.Text = "Add to Cart";
            this.btn_addPants2.UseVisualStyleBackColor = true;
            this.btn_addPants2.Click += new System.EventHandler(this.btn_addPants2_Click);
            // 
            // btn_addPants1
            // 
            this.btn_addPants1.Location = new System.Drawing.Point(12, 320);
            this.btn_addPants1.Name = "btn_addPants1";
            this.btn_addPants1.Size = new System.Drawing.Size(142, 38);
            this.btn_addPants1.TabIndex = 15;
            this.btn_addPants1.Text = "Add to Cart";
            this.btn_addPants1.UseVisualStyleBackColor = true;
            this.btn_addPants1.Click += new System.EventHandler(this.btn_addPants1_Click);
            // 
            // lb_hargaPants3
            // 
            this.lb_hargaPants3.AutoSize = true;
            this.lb_hargaPants3.Location = new System.Drawing.Point(540, 269);
            this.lb_hargaPants3.Name = "lb_hargaPants3";
            this.lb_hargaPants3.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaPants3.TabIndex = 14;
            this.lb_hargaPants3.Text = "Rp500,000.00";
            // 
            // lb_hargaPants2
            // 
            this.lb_hargaPants2.AutoSize = true;
            this.lb_hargaPants2.Location = new System.Drawing.Point(273, 269);
            this.lb_hargaPants2.Name = "lb_hargaPants2";
            this.lb_hargaPants2.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaPants2.TabIndex = 13;
            this.lb_hargaPants2.Text = "Rp400,000.00";
            // 
            // lb_hargaPants1
            // 
            this.lb_hargaPants1.AutoSize = true;
            this.lb_hargaPants1.Location = new System.Drawing.Point(7, 269);
            this.lb_hargaPants1.Name = "lb_hargaPants1";
            this.lb_hargaPants1.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaPants1.TabIndex = 12;
            this.lb_hargaPants1.Text = "Rp300,000.00";
            // 
            // lb_pants3
            // 
            this.lb_pants3.AutoSize = true;
            this.lb_pants3.Location = new System.Drawing.Point(540, 231);
            this.lb_pants3.Name = "lb_pants3";
            this.lb_pants3.Size = new System.Drawing.Size(194, 25);
            this.lb_pants3.TabIndex = 11;
            this.lb_pants3.Text = "Pants Kerja Utilitas";
            // 
            // lb_pants2
            // 
            this.lb_pants2.AutoSize = true;
            this.lb_pants2.Location = new System.Drawing.Point(273, 231);
            this.lb_pants2.Name = "lb_pants2";
            this.lb_pants2.Size = new System.Drawing.Size(218, 25);
            this.lb_pants2.TabIndex = 10;
            this.lb_pants2.Text = "Pants Stretch Slim Fit";
            // 
            // lb_pants1
            // 
            this.lb_pants1.AutoSize = true;
            this.lb_pants1.Location = new System.Drawing.Point(7, 231);
            this.lb_pants1.Name = "lb_pants1";
            this.lb_pants1.Size = new System.Drawing.Size(209, 25);
            this.lb_pants1.TabIndex = 9;
            this.lb_pants1.Text = "AIRism Cotton Pants";
            // 
            // pBox_pants3
            // 
            this.pBox_pants3.Image = global::TH08.Properties.Resources.Pants_Kerja_Utilitas;
            this.pBox_pants3.Location = new System.Drawing.Point(545, 13);
            this.pBox_pants3.Name = "pBox_pants3";
            this.pBox_pants3.Size = new System.Drawing.Size(203, 203);
            this.pBox_pants3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_pants3.TabIndex = 8;
            this.pBox_pants3.TabStop = false;
            // 
            // pBox_pants2
            // 
            this.pBox_pants2.Image = global::TH08.Properties.Resources.Pants_Stretch_Slim_Fit;
            this.pBox_pants2.Location = new System.Drawing.Point(278, 13);
            this.pBox_pants2.Name = "pBox_pants2";
            this.pBox_pants2.Size = new System.Drawing.Size(203, 203);
            this.pBox_pants2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_pants2.TabIndex = 7;
            this.pBox_pants2.TabStop = false;
            // 
            // pBox_pants1
            // 
            this.pBox_pants1.Image = global::TH08.Properties.Resources.AIRism_Cotton_Pants;
            this.pBox_pants1.Location = new System.Drawing.Point(12, 13);
            this.pBox_pants1.Name = "pBox_pants1";
            this.pBox_pants1.Size = new System.Drawing.Size(203, 203);
            this.pBox_pants1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_pants1.TabIndex = 6;
            this.pBox_pants1.TabStop = false;
            // 
            // panel_longPants
            // 
            this.panel_longPants.Controls.Add(this.btn_addLongPants3);
            this.panel_longPants.Controls.Add(this.btn_addLongPants2);
            this.panel_longPants.Controls.Add(this.btn_addLongPants1);
            this.panel_longPants.Controls.Add(this.lb_hargaLongPants3);
            this.panel_longPants.Controls.Add(this.lb_hargaLongPants2);
            this.panel_longPants.Controls.Add(this.lb_hargaLongPants1);
            this.panel_longPants.Controls.Add(this.lb_longPants3);
            this.panel_longPants.Controls.Add(this.lb_longPants2);
            this.panel_longPants.Controls.Add(this.lb_longPants1);
            this.panel_longPants.Controls.Add(this.pBox_longPants3);
            this.panel_longPants.Controls.Add(this.pBox_longPants2);
            this.panel_longPants.Controls.Add(this.pBox_longPants1);
            this.panel_longPants.Location = new System.Drawing.Point(21, 55);
            this.panel_longPants.Name = "panel_longPants";
            this.panel_longPants.Size = new System.Drawing.Size(762, 373);
            this.panel_longPants.TabIndex = 21;
            // 
            // btn_addLongPants3
            // 
            this.btn_addLongPants3.Location = new System.Drawing.Point(545, 320);
            this.btn_addLongPants3.Name = "btn_addLongPants3";
            this.btn_addLongPants3.Size = new System.Drawing.Size(142, 38);
            this.btn_addLongPants3.TabIndex = 17;
            this.btn_addLongPants3.Text = "Add to Cart";
            this.btn_addLongPants3.UseVisualStyleBackColor = true;
            this.btn_addLongPants3.Click += new System.EventHandler(this.btn_addLongPants3_Click);
            // 
            // btn_addLongPants2
            // 
            this.btn_addLongPants2.Location = new System.Drawing.Point(278, 320);
            this.btn_addLongPants2.Name = "btn_addLongPants2";
            this.btn_addLongPants2.Size = new System.Drawing.Size(142, 38);
            this.btn_addLongPants2.TabIndex = 16;
            this.btn_addLongPants2.Text = "Add to Cart";
            this.btn_addLongPants2.UseVisualStyleBackColor = true;
            this.btn_addLongPants2.Click += new System.EventHandler(this.btn_addLongPants2_Click);
            // 
            // btn_addLongPants1
            // 
            this.btn_addLongPants1.Location = new System.Drawing.Point(12, 320);
            this.btn_addLongPants1.Name = "btn_addLongPants1";
            this.btn_addLongPants1.Size = new System.Drawing.Size(142, 38);
            this.btn_addLongPants1.TabIndex = 15;
            this.btn_addLongPants1.Text = "Add to Cart";
            this.btn_addLongPants1.UseVisualStyleBackColor = true;
            this.btn_addLongPants1.Click += new System.EventHandler(this.btn_addLongPants1_Click);
            // 
            // lb_hargaLongPants3
            // 
            this.lb_hargaLongPants3.AutoSize = true;
            this.lb_hargaLongPants3.Location = new System.Drawing.Point(540, 269);
            this.lb_hargaLongPants3.Name = "lb_hargaLongPants3";
            this.lb_hargaLongPants3.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaLongPants3.TabIndex = 14;
            this.lb_hargaLongPants3.Text = "Rp600,000.00";
            // 
            // lb_hargaLongPants2
            // 
            this.lb_hargaLongPants2.AutoSize = true;
            this.lb_hargaLongPants2.Location = new System.Drawing.Point(273, 269);
            this.lb_hargaLongPants2.Name = "lb_hargaLongPants2";
            this.lb_hargaLongPants2.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaLongPants2.TabIndex = 13;
            this.lb_hargaLongPants2.Text = "Rp600,000.00";
            // 
            // lb_hargaLongPants1
            // 
            this.lb_hargaLongPants1.AutoSize = true;
            this.lb_hargaLongPants1.Location = new System.Drawing.Point(7, 269);
            this.lb_hargaLongPants1.Name = "lb_hargaLongPants1";
            this.lb_hargaLongPants1.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaLongPants1.TabIndex = 12;
            this.lb_hargaLongPants1.Text = "Rp400,000.00";
            // 
            // lb_longPants3
            // 
            this.lb_longPants3.AutoSize = true;
            this.lb_longPants3.Location = new System.Drawing.Point(540, 231);
            this.lb_longPants3.Name = "lb_longPants3";
            this.lb_longPants3.Size = new System.Drawing.Size(185, 25);
            this.lb_longPants3.TabIndex = 11;
            this.lb_longPants3.Text = "Long Pants Jeans";
            // 
            // lb_longPants2
            // 
            this.lb_longPants2.AutoSize = true;
            this.lb_longPants2.Location = new System.Drawing.Point(273, 231);
            this.lb_longPants2.Name = "lb_longPants2";
            this.lb_longPants2.Size = new System.Drawing.Size(184, 25);
            this.lb_longPants2.TabIndex = 10;
            this.lb_longPants2.Text = "Long Pants Kargo";
            // 
            // lb_longPants1
            // 
            this.lb_longPants1.AutoSize = true;
            this.lb_longPants1.Location = new System.Drawing.Point(7, 231);
            this.lb_longPants1.Name = "lb_longPants1";
            this.lb_longPants1.Size = new System.Drawing.Size(255, 25);
            this.lb_longPants1.TabIndex = 9;
            this.lb_longPants1.Text = "Long Pants Jogger Katun";
            // 
            // pBox_longPants3
            // 
            this.pBox_longPants3.Image = global::TH08.Properties.Resources.Long_Pants_Jeans_Damaged;
            this.pBox_longPants3.Location = new System.Drawing.Point(545, 13);
            this.pBox_longPants3.Name = "pBox_longPants3";
            this.pBox_longPants3.Size = new System.Drawing.Size(203, 203);
            this.pBox_longPants3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_longPants3.TabIndex = 8;
            this.pBox_longPants3.TabStop = false;
            // 
            // pBox_longPants2
            // 
            this.pBox_longPants2.Image = global::TH08.Properties.Resources.Long_Pants_Kargo;
            this.pBox_longPants2.Location = new System.Drawing.Point(278, 13);
            this.pBox_longPants2.Name = "pBox_longPants2";
            this.pBox_longPants2.Size = new System.Drawing.Size(203, 203);
            this.pBox_longPants2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_longPants2.TabIndex = 7;
            this.pBox_longPants2.TabStop = false;
            // 
            // pBox_longPants1
            // 
            this.pBox_longPants1.Image = global::TH08.Properties.Resources.Long_Pants_Jogger_Katun;
            this.pBox_longPants1.Location = new System.Drawing.Point(12, 13);
            this.pBox_longPants1.Name = "pBox_longPants1";
            this.pBox_longPants1.Size = new System.Drawing.Size(203, 203);
            this.pBox_longPants1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_longPants1.TabIndex = 6;
            this.pBox_longPants1.TabStop = false;
            // 
            // panel_shoes
            // 
            this.panel_shoes.Controls.Add(this.btn_addShoes3);
            this.panel_shoes.Controls.Add(this.btn_addShoes2);
            this.panel_shoes.Controls.Add(this.btn_addShoes1);
            this.panel_shoes.Controls.Add(this.lb_hargaShoes3);
            this.panel_shoes.Controls.Add(this.lb_hargaShoes2);
            this.panel_shoes.Controls.Add(this.lb_hargaShoes1);
            this.panel_shoes.Controls.Add(this.lb_shoes3);
            this.panel_shoes.Controls.Add(this.lb_shoes2);
            this.panel_shoes.Controls.Add(this.lb_shoes1);
            this.panel_shoes.Controls.Add(this.pBox_shoes3);
            this.panel_shoes.Controls.Add(this.pBox_shoes2);
            this.panel_shoes.Controls.Add(this.pBox_shoes1);
            this.panel_shoes.Location = new System.Drawing.Point(21, 55);
            this.panel_shoes.Name = "panel_shoes";
            this.panel_shoes.Size = new System.Drawing.Size(773, 373);
            this.panel_shoes.TabIndex = 22;
            // 
            // btn_addShoes3
            // 
            this.btn_addShoes3.Location = new System.Drawing.Point(545, 320);
            this.btn_addShoes3.Name = "btn_addShoes3";
            this.btn_addShoes3.Size = new System.Drawing.Size(142, 38);
            this.btn_addShoes3.TabIndex = 17;
            this.btn_addShoes3.Text = "Add to Cart";
            this.btn_addShoes3.UseVisualStyleBackColor = true;
            this.btn_addShoes3.Click += new System.EventHandler(this.btn_addShoes3_Click);
            // 
            // btn_addShoes2
            // 
            this.btn_addShoes2.Location = new System.Drawing.Point(278, 320);
            this.btn_addShoes2.Name = "btn_addShoes2";
            this.btn_addShoes2.Size = new System.Drawing.Size(142, 38);
            this.btn_addShoes2.TabIndex = 16;
            this.btn_addShoes2.Text = "Add to Cart";
            this.btn_addShoes2.UseVisualStyleBackColor = true;
            this.btn_addShoes2.Click += new System.EventHandler(this.btn_addShoes2_Click);
            // 
            // btn_addShoes1
            // 
            this.btn_addShoes1.Location = new System.Drawing.Point(12, 320);
            this.btn_addShoes1.Name = "btn_addShoes1";
            this.btn_addShoes1.Size = new System.Drawing.Size(142, 38);
            this.btn_addShoes1.TabIndex = 15;
            this.btn_addShoes1.Text = "Add to Cart";
            this.btn_addShoes1.UseVisualStyleBackColor = true;
            this.btn_addShoes1.Click += new System.EventHandler(this.btn_addShoes1_Click);
            // 
            // lb_hargaShoes3
            // 
            this.lb_hargaShoes3.AutoSize = true;
            this.lb_hargaShoes3.Location = new System.Drawing.Point(540, 269);
            this.lb_hargaShoes3.Name = "lb_hargaShoes3";
            this.lb_hargaShoes3.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaShoes3.TabIndex = 14;
            this.lb_hargaShoes3.Text = "Rp600,000.00";
            // 
            // lb_hargaShoes2
            // 
            this.lb_hargaShoes2.AutoSize = true;
            this.lb_hargaShoes2.Location = new System.Drawing.Point(273, 269);
            this.lb_hargaShoes2.Name = "lb_hargaShoes2";
            this.lb_hargaShoes2.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaShoes2.TabIndex = 13;
            this.lb_hargaShoes2.Text = "Rp400,000.00";
            // 
            // lb_hargaShoes1
            // 
            this.lb_hargaShoes1.AutoSize = true;
            this.lb_hargaShoes1.Location = new System.Drawing.Point(7, 269);
            this.lb_hargaShoes1.Name = "lb_hargaShoes1";
            this.lb_hargaShoes1.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaShoes1.TabIndex = 12;
            this.lb_hargaShoes1.Text = "Rp400,000.00";
            // 
            // lb_shoes3
            // 
            this.lb_shoes3.AutoSize = true;
            this.lb_shoes3.Location = new System.Drawing.Point(540, 231);
            this.lb_shoes3.Name = "lb_shoes3";
            this.lb_shoes3.Size = new System.Drawing.Size(233, 25);
            this.lb_shoes3.TabIndex = 11;
            this.lb_shoes3.Text = "Shoes Slip On Kanvas ";
            // 
            // lb_shoes2
            // 
            this.lb_shoes2.AutoSize = true;
            this.lb_shoes2.Location = new System.Drawing.Point(273, 231);
            this.lb_shoes2.Name = "lb_shoes2";
            this.lb_shoes2.Size = new System.Drawing.Size(145, 25);
            this.lb_shoes2.TabIndex = 10;
            this.lb_shoes2.Text = "Shoes Kasual";
            // 
            // lb_shoes1
            // 
            this.lb_shoes1.AutoSize = true;
            this.lb_shoes1.Location = new System.Drawing.Point(7, 231);
            this.lb_shoes1.Name = "lb_shoes1";
            this.lb_shoes1.Size = new System.Drawing.Size(170, 25);
            this.lb_shoes1.TabIndex = 9;
            this.lb_shoes1.Text = "Shoes Sneakers";
            // 
            // pBox_shoes3
            // 
            this.pBox_shoes3.Image = global::TH08.Properties.Resources.Shoes_Slip_On_Kanvas;
            this.pBox_shoes3.Location = new System.Drawing.Point(545, 13);
            this.pBox_shoes3.Name = "pBox_shoes3";
            this.pBox_shoes3.Size = new System.Drawing.Size(203, 203);
            this.pBox_shoes3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_shoes3.TabIndex = 8;
            this.pBox_shoes3.TabStop = false;
            // 
            // pBox_shoes2
            // 
            this.pBox_shoes2.Image = global::TH08.Properties.Resources.Shoes_Kasual_Comfeel_Touch;
            this.pBox_shoes2.Location = new System.Drawing.Point(278, 13);
            this.pBox_shoes2.Name = "pBox_shoes2";
            this.pBox_shoes2.Size = new System.Drawing.Size(203, 203);
            this.pBox_shoes2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_shoes2.TabIndex = 7;
            this.pBox_shoes2.TabStop = false;
            // 
            // pBox_shoes1
            // 
            this.pBox_shoes1.Image = global::TH08.Properties.Resources.Shoes_Sneakers;
            this.pBox_shoes1.Location = new System.Drawing.Point(12, 13);
            this.pBox_shoes1.Name = "pBox_shoes1";
            this.pBox_shoes1.Size = new System.Drawing.Size(203, 203);
            this.pBox_shoes1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_shoes1.TabIndex = 6;
            this.pBox_shoes1.TabStop = false;
            // 
            // panel_jewel
            // 
            this.panel_jewel.Controls.Add(this.btn_addJewel3);
            this.panel_jewel.Controls.Add(this.btn_addJewel2);
            this.panel_jewel.Controls.Add(this.btn_addJewel1);
            this.panel_jewel.Controls.Add(this.lb_hargaJewel3);
            this.panel_jewel.Controls.Add(this.lb_hargaJewel2);
            this.panel_jewel.Controls.Add(this.lb_hargaJewel1);
            this.panel_jewel.Controls.Add(this.lb_jewel3);
            this.panel_jewel.Controls.Add(this.lb_jewel2);
            this.panel_jewel.Controls.Add(this.lb_jewel1);
            this.panel_jewel.Controls.Add(this.pBox_jewel3);
            this.panel_jewel.Controls.Add(this.pBox_jewel2);
            this.panel_jewel.Controls.Add(this.pBox_jewel1);
            this.panel_jewel.Location = new System.Drawing.Point(21, 55);
            this.panel_jewel.Name = "panel_jewel";
            this.panel_jewel.Size = new System.Drawing.Size(773, 373);
            this.panel_jewel.TabIndex = 23;
            // 
            // btn_addJewel3
            // 
            this.btn_addJewel3.Location = new System.Drawing.Point(545, 320);
            this.btn_addJewel3.Name = "btn_addJewel3";
            this.btn_addJewel3.Size = new System.Drawing.Size(142, 38);
            this.btn_addJewel3.TabIndex = 17;
            this.btn_addJewel3.Text = "Add to Cart";
            this.btn_addJewel3.UseVisualStyleBackColor = true;
            this.btn_addJewel3.Click += new System.EventHandler(this.btn_addJewel3_Click);
            // 
            // btn_addJewel2
            // 
            this.btn_addJewel2.Location = new System.Drawing.Point(278, 320);
            this.btn_addJewel2.Name = "btn_addJewel2";
            this.btn_addJewel2.Size = new System.Drawing.Size(142, 38);
            this.btn_addJewel2.TabIndex = 16;
            this.btn_addJewel2.Text = "Add to Cart";
            this.btn_addJewel2.UseVisualStyleBackColor = true;
            this.btn_addJewel2.Click += new System.EventHandler(this.btn_addJewel2_Click);
            // 
            // btn_addJewel1
            // 
            this.btn_addJewel1.Location = new System.Drawing.Point(12, 320);
            this.btn_addJewel1.Name = "btn_addJewel1";
            this.btn_addJewel1.Size = new System.Drawing.Size(142, 38);
            this.btn_addJewel1.TabIndex = 15;
            this.btn_addJewel1.Text = "Add to Cart";
            this.btn_addJewel1.UseVisualStyleBackColor = true;
            this.btn_addJewel1.Click += new System.EventHandler(this.btn_addJewel1_Click);
            // 
            // lb_hargaJewel3
            // 
            this.lb_hargaJewel3.AutoSize = true;
            this.lb_hargaJewel3.Location = new System.Drawing.Point(540, 269);
            this.lb_hargaJewel3.Name = "lb_hargaJewel3";
            this.lb_hargaJewel3.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaJewel3.TabIndex = 14;
            this.lb_hargaJewel3.Text = "Rp140,000.00";
            // 
            // lb_hargaJewel2
            // 
            this.lb_hargaJewel2.AutoSize = true;
            this.lb_hargaJewel2.Location = new System.Drawing.Point(273, 269);
            this.lb_hargaJewel2.Name = "lb_hargaJewel2";
            this.lb_hargaJewel2.Size = new System.Drawing.Size(147, 25);
            this.lb_hargaJewel2.TabIndex = 13;
            this.lb_hargaJewel2.Text = "Rp110,000.00";
            // 
            // lb_hargaJewel1
            // 
            this.lb_hargaJewel1.AutoSize = true;
            this.lb_hargaJewel1.Location = new System.Drawing.Point(7, 269);
            this.lb_hargaJewel1.Name = "lb_hargaJewel1";
            this.lb_hargaJewel1.Size = new System.Drawing.Size(135, 25);
            this.lb_hargaJewel1.TabIndex = 12;
            this.lb_hargaJewel1.Text = "Rp80,000.00";
            // 
            // lb_jewel3
            // 
            this.lb_jewel3.AutoSize = true;
            this.lb_jewel3.Location = new System.Drawing.Point(540, 231);
            this.lb_jewel3.Name = "lb_jewel3";
            this.lb_jewel3.Size = new System.Drawing.Size(186, 25);
            this.lb_jewel3.TabIndex = 11;
            this.lb_jewel3.Text = "Gelang Silver Star";
            // 
            // lb_jewel2
            // 
            this.lb_jewel2.AutoSize = true;
            this.lb_jewel2.Location = new System.Drawing.Point(273, 231);
            this.lb_jewel2.Name = "lb_jewel2";
            this.lb_jewel2.Size = new System.Drawing.Size(220, 25);
            this.lb_jewel2.TabIndex = 10;
            this.lb_jewel2.Text = "Kalung Bintang Perak";
            // 
            // lb_jewel1
            // 
            this.lb_jewel1.AutoSize = true;
            this.lb_jewel1.Location = new System.Drawing.Point(7, 231);
            this.lb_jewel1.Name = "lb_jewel1";
            this.lb_jewel1.Size = new System.Drawing.Size(200, 25);
            this.lb_jewel1.TabIndex = 9;
            this.lb_jewel1.Text = "Cincin Emas Bunga";
            // 
            // pBox_jewel3
            // 
            this.pBox_jewel3.Image = global::TH08.Properties.Resources.Gelang_Silver_Liontin_Star;
            this.pBox_jewel3.Location = new System.Drawing.Point(545, 13);
            this.pBox_jewel3.Name = "pBox_jewel3";
            this.pBox_jewel3.Size = new System.Drawing.Size(203, 203);
            this.pBox_jewel3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_jewel3.TabIndex = 8;
            this.pBox_jewel3.TabStop = false;
            // 
            // pBox_jewel2
            // 
            this.pBox_jewel2.Image = global::TH08.Properties.Resources.Kalung_Bintang_Perak;
            this.pBox_jewel2.Location = new System.Drawing.Point(278, 13);
            this.pBox_jewel2.Name = "pBox_jewel2";
            this.pBox_jewel2.Size = new System.Drawing.Size(203, 203);
            this.pBox_jewel2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_jewel2.TabIndex = 7;
            this.pBox_jewel2.TabStop = false;
            // 
            // pBox_jewel1
            // 
            this.pBox_jewel1.Image = global::TH08.Properties.Resources.Cincin_Emas_Bunga;
            this.pBox_jewel1.Location = new System.Drawing.Point(12, 13);
            this.pBox_jewel1.Name = "pBox_jewel1";
            this.pBox_jewel1.Size = new System.Drawing.Size(203, 203);
            this.pBox_jewel1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_jewel1.TabIndex = 6;
            this.pBox_jewel1.TabStop = false;
            // 
            // lb_uploadImage
            // 
            this.lb_uploadImage.AutoSize = true;
            this.lb_uploadImage.Location = new System.Drawing.Point(12, 21);
            this.lb_uploadImage.Name = "lb_uploadImage";
            this.lb_uploadImage.Size = new System.Drawing.Size(144, 25);
            this.lb_uploadImage.TabIndex = 24;
            this.lb_uploadImage.Text = "Upload Image";
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(172, 12);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(130, 43);
            this.btn_upload.TabIndex = 25;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // pBox_others
            // 
            this.pBox_others.Location = new System.Drawing.Point(17, 88);
            this.pBox_others.Name = "pBox_others";
            this.pBox_others.Size = new System.Drawing.Size(199, 198);
            this.pBox_others.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pBox_others.TabIndex = 26;
            this.pBox_others.TabStop = false;
            // 
            // lb_itemName
            // 
            this.lb_itemName.AutoSize = true;
            this.lb_itemName.Location = new System.Drawing.Point(242, 88);
            this.lb_itemName.Name = "lb_itemName";
            this.lb_itemName.Size = new System.Drawing.Size(120, 25);
            this.lb_itemName.TabIndex = 27;
            this.lb_itemName.Text = "Item Name:";
            // 
            // lb_itemPrice
            // 
            this.lb_itemPrice.AutoSize = true;
            this.lb_itemPrice.Location = new System.Drawing.Point(242, 140);
            this.lb_itemPrice.Name = "lb_itemPrice";
            this.lb_itemPrice.Size = new System.Drawing.Size(113, 25);
            this.lb_itemPrice.TabIndex = 28;
            this.lb_itemPrice.Text = "Item Price:";
            // 
            // tBox_itemName
            // 
            this.tBox_itemName.Location = new System.Drawing.Point(368, 85);
            this.tBox_itemName.Name = "tBox_itemName";
            this.tBox_itemName.Size = new System.Drawing.Size(276, 31);
            this.tBox_itemName.TabIndex = 29;
            this.tBox_itemName.TextChanged += new System.EventHandler(this.tBox_itemName_TextChanged);
            // 
            // tBox_itemPrice
            // 
            this.tBox_itemPrice.Location = new System.Drawing.Point(368, 137);
            this.tBox_itemPrice.Name = "tBox_itemPrice";
            this.tBox_itemPrice.Size = new System.Drawing.Size(276, 31);
            this.tBox_itemPrice.TabIndex = 30;
            this.tBox_itemPrice.TextChanged += new System.EventHandler(this.tBox_itemPrice_TextChanged);
            this.tBox_itemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_itemPrice_KeyPress);
            // 
            // btn_addOthers
            // 
            this.btn_addOthers.Location = new System.Drawing.Point(368, 209);
            this.btn_addOthers.Name = "btn_addOthers";
            this.btn_addOthers.Size = new System.Drawing.Size(142, 38);
            this.btn_addOthers.TabIndex = 18;
            this.btn_addOthers.Text = "Add to Cart";
            this.btn_addOthers.UseVisualStyleBackColor = true;
            this.btn_addOthers.Click += new System.EventHandler(this.btn_addOthers_Click);
            // 
            // panel_others
            // 
            this.panel_others.Controls.Add(this.btn_addOthers);
            this.panel_others.Controls.Add(this.tBox_itemPrice);
            this.panel_others.Controls.Add(this.tBox_itemName);
            this.panel_others.Controls.Add(this.lb_itemPrice);
            this.panel_others.Controls.Add(this.lb_itemName);
            this.panel_others.Controls.Add(this.pBox_others);
            this.panel_others.Controls.Add(this.btn_upload);
            this.panel_others.Controls.Add(this.lb_uploadImage);
            this.panel_others.Location = new System.Drawing.Point(21, 55);
            this.panel_others.Name = "panel_others";
            this.panel_others.Size = new System.Drawing.Size(659, 313);
            this.panel_others.TabIndex = 31;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1442, 623);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(115, 44);
            this.btn_delete.TabIndex = 32;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // form_uniqme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1587, 995);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.panel_others);
            this.Controls.Add(this.panel_jewel);
            this.Controls.Add(this.panel_shoes);
            this.Controls.Add(this.panel_longPants);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.panel_shirt);
            this.Controls.Add(this.panel_tShirt);
            this.Controls.Add(this.tBox_total);
            this.Controls.Add(this.tBox_subTotal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv_tabel);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "form_uniqme";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.form_uniqme_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_tabel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_tShirt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_tShirt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_tShirt3)).EndInit();
            this.panel_tShirt.ResumeLayout(false);
            this.panel_tShirt.PerformLayout();
            this.panel_shirt.ResumeLayout(false);
            this.panel_shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shirt3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shirt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shirt1)).EndInit();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_pants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_pants2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_pants1)).EndInit();
            this.panel_longPants.ResumeLayout(false);
            this.panel_longPants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_longPants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_longPants2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_longPants1)).EndInit();
            this.panel_shoes.ResumeLayout(false);
            this.panel_shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shoes3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shoes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_shoes1)).EndInit();
            this.panel_jewel.ResumeLayout(false);
            this.panel_jewel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_jewel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_jewel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_jewel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_others)).EndInit();
            this.panel_others.ResumeLayout(false);
            this.panel_others.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_tabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBox_subTotal;
        private System.Windows.Forms.TextBox tBox_total;
        private System.Windows.Forms.PictureBox pBox_tShirt1;
        private System.Windows.Forms.PictureBox pBox_tShirt2;
        private System.Windows.Forms.PictureBox pBox_tShirt3;
        private System.Windows.Forms.Label lb_tShirt1;
        private System.Windows.Forms.Label lb_tShirt2;
        private System.Windows.Forms.Label lb_tShirt3;
        private System.Windows.Forms.Label lb_hargaTShirt1;
        private System.Windows.Forms.Label lb_hargaTShirt2;
        private System.Windows.Forms.Label lb_hargaTShirt3;
        private System.Windows.Forms.Button btn_addTShirt1;
        private System.Windows.Forms.Button btn_addTShirt2;
        private System.Windows.Forms.Button btn_addTShirt3;
        private System.Windows.Forms.Panel panel_tShirt;
        private System.Windows.Forms.Panel panel_shirt;
        private System.Windows.Forms.Button btn_addShirt3;
        private System.Windows.Forms.Button btn_addShirt2;
        private System.Windows.Forms.Button btn_addShirt1;
        private System.Windows.Forms.Label lb_hargaShirt3;
        private System.Windows.Forms.Label lb_hargaShirt2;
        private System.Windows.Forms.Label lb_hargaShirt1;
        private System.Windows.Forms.Label lb_shirt3;
        private System.Windows.Forms.Label lb_shirt2;
        private System.Windows.Forms.Label lb_shirt1;
        private System.Windows.Forms.PictureBox pBox_shirt3;
        private System.Windows.Forms.PictureBox pBox_shirt2;
        private System.Windows.Forms.PictureBox pBox_shirt1;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.Button btn_addPants3;
        private System.Windows.Forms.Button btn_addPants2;
        private System.Windows.Forms.Button btn_addPants1;
        private System.Windows.Forms.Label lb_hargaPants3;
        private System.Windows.Forms.Label lb_hargaPants2;
        private System.Windows.Forms.Label lb_hargaPants1;
        private System.Windows.Forms.Label lb_pants3;
        private System.Windows.Forms.Label lb_pants2;
        private System.Windows.Forms.Label lb_pants1;
        private System.Windows.Forms.PictureBox pBox_pants3;
        private System.Windows.Forms.PictureBox pBox_pants2;
        private System.Windows.Forms.PictureBox pBox_pants1;
        private System.Windows.Forms.Panel panel_longPants;
        private System.Windows.Forms.Button btn_addLongPants3;
        private System.Windows.Forms.Button btn_addLongPants2;
        private System.Windows.Forms.Button btn_addLongPants1;
        private System.Windows.Forms.Label lb_hargaLongPants3;
        private System.Windows.Forms.Label lb_hargaLongPants2;
        private System.Windows.Forms.Label lb_hargaLongPants1;
        private System.Windows.Forms.Label lb_longPants3;
        private System.Windows.Forms.Label lb_longPants2;
        private System.Windows.Forms.Label lb_longPants1;
        private System.Windows.Forms.PictureBox pBox_longPants3;
        private System.Windows.Forms.PictureBox pBox_longPants2;
        private System.Windows.Forms.PictureBox pBox_longPants1;
        private System.Windows.Forms.Panel panel_shoes;
        private System.Windows.Forms.Button btn_addShoes3;
        private System.Windows.Forms.Button btn_addShoes2;
        private System.Windows.Forms.Button btn_addShoes1;
        private System.Windows.Forms.Label lb_hargaShoes3;
        private System.Windows.Forms.Label lb_hargaShoes2;
        private System.Windows.Forms.Label lb_hargaShoes1;
        private System.Windows.Forms.Label lb_shoes3;
        private System.Windows.Forms.Label lb_shoes2;
        private System.Windows.Forms.Label lb_shoes1;
        private System.Windows.Forms.PictureBox pBox_shoes3;
        private System.Windows.Forms.PictureBox pBox_shoes2;
        private System.Windows.Forms.PictureBox pBox_shoes1;
        private System.Windows.Forms.Panel panel_jewel;
        private System.Windows.Forms.Button btn_addJewel3;
        private System.Windows.Forms.Button btn_addJewel2;
        private System.Windows.Forms.Button btn_addJewel1;
        private System.Windows.Forms.Label lb_hargaJewel3;
        private System.Windows.Forms.Label lb_hargaJewel2;
        private System.Windows.Forms.Label lb_hargaJewel1;
        private System.Windows.Forms.Label lb_jewel3;
        private System.Windows.Forms.Label lb_jewel2;
        private System.Windows.Forms.Label lb_jewel1;
        private System.Windows.Forms.PictureBox pBox_jewel3;
        private System.Windows.Forms.PictureBox pBox_jewel2;
        private System.Windows.Forms.PictureBox pBox_jewel1;
        private System.Windows.Forms.Label lb_uploadImage;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.PictureBox pBox_others;
        private System.Windows.Forms.Label lb_itemName;
        private System.Windows.Forms.Label lb_itemPrice;
        private System.Windows.Forms.TextBox tBox_itemName;
        private System.Windows.Forms.TextBox tBox_itemPrice;
        private System.Windows.Forms.Button btn_addOthers;
        private System.Windows.Forms.Panel panel_others;
        private System.Windows.Forms.Button btn_delete;
    }
}

