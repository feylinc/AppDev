﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH08
{
    public partial class form_uniqme : Form
    {
        DataTable dtTabel = new DataTable();

        int qtyTShirt1 = 0;
        int qtyTShirt2 = 0;
        int qtyTShirt3 = 0;
        int qtyShirt1 = 0;
        int qtyShirt2 = 0;
        int qtyShirt3 = 0;
        int qtyPants1 = 0;
        int qtyPants2 = 0;
        int qtyPants3 = 0;
        int qtyLongPants1 = 0;
        int qtyLongPants2 = 0;
        int qtyLongPants3 = 0;
        int qtyShoes1 = 0;
        int qtyShoes2 = 0;
        int qtyShoes3 = 0;
        int qtyJewel1 = 0;
        int qtyJewel2 = 0;
        int qtyJewel3 = 0;
        int qtyOthers = 0;

        public form_uniqme()
        {
            InitializeComponent();
        }

        private void form_uniqme_Load(object sender, EventArgs e)
        {
            panel_tShirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;

            tBox_subTotal.Enabled = false;
            tBox_total.Enabled = false;

            dtTabel.Columns.Add("Item Name");
            dtTabel.Columns.Add("Quantity");
            dtTabel.Columns.Add("Price");
            dtTabel.Columns.Add("Total");

            dgv_tabel.DataSource = dtTabel;
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_shirt.Visible = false;
            panel_tShirt.Visible = true;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tShirt.Visible = false;
            panel_shirt.Visible = true;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tShirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = true;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tShirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = true;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tShirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = true;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tShirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = true;
            panel_others.Visible = false;
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tShirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = true;

            tBox_itemName.Enabled = false;
            tBox_itemPrice.Enabled = false;
            btn_addOthers.Enabled = false;

            tBox_itemName.Clear();
            tBox_itemPrice.Clear();

            pBox_others.Image = null;
        }

        private void btn_addTShirt1_Click(object sender, EventArgs e)
        {
            int priceTShirt1 = 120000;

            qtyTShirt1++;

            string totalTShirt1 = "Rp" + (priceTShirt1 * qtyTShirt1).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_tShirt1.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_tShirt1.Text)
                    {
                        dtTabel.Rows[i][1] = qtyTShirt1.ToString();
                        dtTabel.Rows[i][3] = totalTShirt1;
                    }
                }
            }
            else
            {
                qtyTShirt1 = 1;

                totalTShirt1 = "Rp" + (priceTShirt1 * qtyTShirt1).ToString();

                dtTabel.Rows.Add(lb_tShirt1.Text, qtyTShirt1.ToString(), lb_hargaTShirt1.Text, totalTShirt1);
            }

            hitungTotal();
        }

        private void btn_addTShirt2_Click(object sender, EventArgs e)
        {
            int priceTShirt2 = 150000;

            qtyTShirt2++;

            string totalTShirt2 = "Rp" + (priceTShirt2 * qtyTShirt2).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_tShirt2.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_tShirt2.Text)
                    {
                        dtTabel.Rows[i][1] = qtyTShirt2.ToString();
                        dtTabel.Rows[i][3] = totalTShirt2;
                    }
                }
            }
            else
            {
                qtyTShirt2 = 1;

                totalTShirt2 = "Rp" + (priceTShirt2 * qtyTShirt2).ToString();

                dtTabel.Rows.Add(lb_tShirt2.Text, qtyTShirt2.ToString(), lb_hargaTShirt2.Text, totalTShirt2);
            }

            hitungTotal();
        }

        private void btn_addTShirt3_Click(object sender, EventArgs e)
        {
            int priceTShirt3 = 170000;

            qtyTShirt3++;

            string totalTShirt3 = "Rp" + (priceTShirt3 * qtyTShirt3).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_tShirt3.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_tShirt3.Text)
                    {
                        dtTabel.Rows[i][1] = qtyTShirt3.ToString();
                        dtTabel.Rows[i][3] = totalTShirt3;
                    }
                }
            }
            else
            {
                qtyTShirt3 = 1;

                totalTShirt3 = "Rp" + (priceTShirt3 * qtyTShirt3).ToString();

                dtTabel.Rows.Add(lb_tShirt3.Text, qtyTShirt3.ToString(), lb_hargaTShirt3.Text, totalTShirt3);
            }

            hitungTotal();
        }

        private void btn_addShirt1_Click(object sender, EventArgs e)
        {
            int priceShirt1 = 230000;

            qtyShirt1++;

            string totalShirt1 = "Rp" + (priceShirt1 * qtyShirt1).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_shirt1.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_shirt1.Text)
                    {
                        dtTabel.Rows[i][1] = qtyShirt1.ToString();
                        dtTabel.Rows[i][3] = totalShirt1;
                    }
                }
            }
            else
            {
                qtyShirt1 = 1;

                totalShirt1 = "Rp" + (priceShirt1 * qtyShirt1).ToString();

                dtTabel.Rows.Add(lb_shirt1.Text, qtyShirt1.ToString(), lb_hargaShirt1.Text, totalShirt1);
            }

            hitungTotal();
        }

        private void btn_addShirt2_Click(object sender, EventArgs e)
        {
            int priceShirt2 = 350000;

            qtyShirt2++;

            string totalShirt2 = "Rp" + (priceShirt2 * qtyShirt2).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_shirt2.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_shirt2.Text)
                    {
                        dtTabel.Rows[i][1] = qtyShirt2.ToString();
                        dtTabel.Rows[i][3] = totalShirt2;
                    }
                }
            }
            else
            {
                qtyShirt2 = 1;

                totalShirt2 = "Rp" + (priceShirt2 * qtyTShirt2).ToString();

                dtTabel.Rows.Add(lb_shirt2.Text, qtyShirt2.ToString(), lb_hargaShirt2.Text, totalShirt2);
            }

            hitungTotal();
        }

        private void btn_addShirt3_Click(object sender, EventArgs e)
        {
            int priceShirt3 = 400000;

            qtyShirt3++;

            string totalShirt3 = "Rp" + (priceShirt3 * qtyShirt3).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_shirt3.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_shirt3.Text)
                    {
                        dtTabel.Rows[i][1] = qtyShirt3.ToString();
                        dtTabel.Rows[i][3] = totalShirt3;
                    }
                }
            }
            else
            {
                qtyShirt3 = 1;

                totalShirt3 = "Rp" + (priceShirt3 * qtyShirt3).ToString();

                dtTabel.Rows.Add(lb_shirt3.Text, qtyShirt3.ToString(), lb_hargaShirt3.Text, totalShirt3);
            }

            hitungTotal();
        }

        private void btn_addPants1_Click(object sender, EventArgs e)
        {
            int pricePants1 = 300000;

            qtyPants1++;

            string totalPants1 = "Rp" + (pricePants1 * qtyPants1).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_pants1.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_pants1.Text)
                    {
                        dtTabel.Rows[i][1] = qtyPants1.ToString();
                        dtTabel.Rows[i][3] = totalPants1;
                    }
                }
            }
            else
            {
                qtyPants1 = 1;

                totalPants1 = "Rp" + (pricePants1 * qtyPants1).ToString();

                dtTabel.Rows.Add(lb_pants1.Text, qtyPants1.ToString(), lb_hargaPants1.Text, totalPants1);
            }

            hitungTotal();
        }

        private void btn_addPants2_Click(object sender, EventArgs e)
        {
            int pricePants2 = 400000;

            qtyPants2++;

            string totalPants2 = "Rp" + (pricePants2 * qtyPants2).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_pants2.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_pants2.Text)
                    {
                        dtTabel.Rows[i][1] = qtyPants2.ToString();
                        dtTabel.Rows[i][3] = totalPants2;
                    }
                }
            }
            else
            {
                qtyPants2 = 1;

                totalPants2 = "Rp" + (pricePants2 * qtyPants2).ToString();

                dtTabel.Rows.Add(lb_pants2.Text, qtyPants2.ToString(), lb_hargaPants2.Text, totalPants2);
            }

            hitungTotal();
        }

        private void btn_addPants3_Click(object sender, EventArgs e)
        {
            int pricePants3 = 500000;

            qtyPants3++;

            string totalPants3 = "Rp" + (pricePants3 * qtyPants3).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_pants3.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_pants3.Text)
                    {
                        dtTabel.Rows[i][1] = qtyPants3.ToString();
                        dtTabel.Rows[i][3] = totalPants3;
                    }
                }
            }
            else
            {
                qtyPants3 = 1;

                totalPants3 = "Rp" + (pricePants3 * qtyPants3).ToString();

                dtTabel.Rows.Add(lb_pants3.Text, qtyPants3.ToString(), lb_hargaPants3.Text, totalPants3);
            }

            hitungTotal();
        }

        private void btn_addLongPants1_Click(object sender, EventArgs e)
        {
            int priceLongPants1 = 400000;

            qtyLongPants1++;

            string totalLongPants1 = "Rp" + (priceLongPants1 * qtyLongPants1).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_longPants1.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_longPants1.Text)
                    {
                        dtTabel.Rows[i][1] = qtyLongPants1.ToString();
                        dtTabel.Rows[i][3] = totalLongPants1;
                    }
                }
            }
            else
            {
                qtyLongPants1 = 1;

                totalLongPants1 = "Rp" + (priceLongPants1 * qtyLongPants1).ToString();

                dtTabel.Rows.Add(lb_longPants1.Text, qtyLongPants1.ToString(), lb_hargaLongPants1.Text, totalLongPants1);
            }

            hitungTotal();
        }

        private void btn_addLongPants2_Click(object sender, EventArgs e)
        {
            int priceLongPants2 = 600000;

            qtyLongPants2++;

            string totalLongPants2 = "Rp" + (priceLongPants2 * qtyLongPants2).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_longPants2.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_longPants2.Text)
                    {
                        dtTabel.Rows[i][1] = qtyLongPants2.ToString();
                        dtTabel.Rows[i][3] = totalLongPants2;
                    }
                }
            }
            else
            {
                qtyLongPants2 = 1;

                totalLongPants2 = "Rp" + (priceLongPants2 * qtyLongPants2).ToString();

                dtTabel.Rows.Add(lb_longPants2.Text, qtyLongPants2.ToString(), lb_hargaLongPants2.Text, totalLongPants2);
            }

            hitungTotal();
        }

        private void btn_addLongPants3_Click(object sender, EventArgs e)
        {
            int priceLongPants3 = 600000;

            qtyLongPants3++;

            string totalLongPants3 = "Rp" + (priceLongPants3 * qtyLongPants3).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_longPants3.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_longPants3.Text)
                    {
                        dtTabel.Rows[i][1] = qtyLongPants3.ToString();
                        dtTabel.Rows[i][3] = totalLongPants3;
                    }
                }
            }
            else
            {
                qtyLongPants3 = 1;

                totalLongPants3 = "Rp" + (priceLongPants3 * qtyLongPants3).ToString();

                dtTabel.Rows.Add(lb_longPants3.Text, qtyLongPants3.ToString(), lb_hargaLongPants3.Text, totalLongPants3);
            }

            hitungTotal();
        }

        private void btn_addShoes1_Click(object sender, EventArgs e)
        {
            int priceShoes1 = 400000;

            qtyShoes1++;

            string totalShoes1 = "Rp" + (priceShoes1 * qtyShoes1).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_shoes1.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_shoes1.Text)
                    {
                        dtTabel.Rows[i][1] = qtyShoes1.ToString();
                        dtTabel.Rows[i][3] = totalShoes1;
                    }
                }
            }
            else
            {
                qtyShoes1 = 1;

                totalShoes1 = "Rp" + (priceShoes1 * qtyShoes1).ToString();

                dtTabel.Rows.Add(lb_shoes1.Text, qtyShoes1.ToString(), lb_hargaShoes1.Text, totalShoes1);
            }

            hitungTotal();
        }

        private void btn_addShoes2_Click(object sender, EventArgs e)
        {
            int priceShoes2 = 400000;

            qtyShoes2++;

            string totalShoes2 = "Rp" + (priceShoes2 * qtyShoes2).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_shoes2.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_shoes2.Text)
                    {
                        dtTabel.Rows[i][1] = qtyShoes2.ToString();
                        dtTabel.Rows[i][3] = totalShoes2;
                    }
                }
            }
            else
            {
                qtyShoes2 = 1;

                totalShoes2 = "Rp" + (priceShoes2 * qtyShoes2).ToString();

                dtTabel.Rows.Add(lb_shoes2.Text, qtyShoes2.ToString(), lb_hargaShoes2.Text, totalShoes2);
            }

            hitungTotal();
        }

        private void btn_addShoes3_Click(object sender, EventArgs e)
        {
            int priceShoes3 = 600000;

            qtyShoes3++;

            string totalShoes3 = "Rp" + (priceShoes3 * qtyShoes3).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_shoes3.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_shoes3.Text)
                    {
                        dtTabel.Rows[i][1] = qtyShoes3.ToString();
                        dtTabel.Rows[i][3] = totalShoes3;
                    }
                }
            }
            else
            {
                qtyShoes3 = 1;

                totalShoes3 = "Rp" + (priceShoes3 * qtyShoes3).ToString();

                dtTabel.Rows.Add(lb_shoes3.Text, qtyShoes3.ToString(), lb_hargaShoes3.Text, totalShoes3);
            }

            hitungTotal();
        }

        private void btn_addJewel1_Click(object sender, EventArgs e)
        {
            int priceJewel1 = 80000;

            qtyJewel1++;

            string totalJewel1 = "Rp" + (priceJewel1 * qtyJewel1).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_jewel1.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_jewel1.Text)
                    {
                        dtTabel.Rows[i][1] = qtyJewel1.ToString();
                        dtTabel.Rows[i][3] = totalJewel1;
                    }
                }
            }
            else
            {
                qtyJewel1 = 1;

                totalJewel1 = "Rp" + (priceJewel1 * qtyJewel1).ToString();

                dtTabel.Rows.Add(lb_jewel1.Text, qtyJewel1.ToString(), lb_hargaJewel1.Text, totalJewel1);
            }

            hitungTotal();
        }

        private void btn_addJewel2_Click(object sender, EventArgs e)
        {
            int priceJewel2 = 110000;

            qtyJewel2++;

            string totalJewel2 = "Rp" + (priceJewel2 * qtyJewel2).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_jewel2.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_jewel2.Text)
                    {
                        dtTabel.Rows[i][1] = qtyJewel2.ToString();
                        dtTabel.Rows[i][3] = totalJewel2;
                    }
                }
            }
            else
            {
                qtyJewel2 = 1;

                totalJewel2 = "Rp" + (priceJewel2 * qtyJewel2).ToString();

                dtTabel.Rows.Add(lb_jewel2.Text, qtyJewel2.ToString(), lb_hargaJewel2.Text, totalJewel2);
            }

            hitungTotal();
        }

        private void btn_addJewel3_Click(object sender, EventArgs e)
        {
            int priceJewel3 = 140000;

            qtyJewel3++;

            string totalJewel3 = "Rp" + (priceJewel3 * qtyJewel3).ToString();

            bool exist = false;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                if (dtTabel.Rows[i][0].ToString() == lb_jewel3.Text)
                {
                    exist = true;
                    break;
                }
            }

            if (exist)
            {
                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == lb_jewel3.Text)
                    {
                        dtTabel.Rows[i][1] = qtyJewel3.ToString();
                        dtTabel.Rows[i][3] = totalJewel3;
                    }
                }
            }
            else
            {
                qtyJewel3 = 1;

                totalJewel3 = "Rp" + (priceJewel3 * qtyJewel3).ToString();

                dtTabel.Rows.Add(lb_jewel3.Text, qtyJewel3.ToString(), lb_hargaJewel3.Text, totalJewel3);
            }

            hitungTotal();
        }

        private void btn_addOthers_Click(object sender, EventArgs e)
        {
            if (tBox_itemName.Text != "" && tBox_itemPrice.Text != "")
            {
                string strPriceItemPrice = "Rp" + tBox_itemPrice.Text;

                bool cek = false;

                for (int i = 0; i < dtTabel.Rows.Count; i++)
                {
                    if (dtTabel.Rows[i][0].ToString() == tBox_itemName.Text && dtTabel.Rows[i][2].ToString() != strPriceItemPrice)
                    {
                        cek = true;
                        break;
                    }
                }

                if (cek)
                {
                    MessageBox.Show("Produk dengan nama yang sama telah terdaftar", "Error");

                    tBox_itemName.Clear();
                    tBox_itemPrice.Clear();
                }
                else
                {
                    int priceItemPrice = Convert.ToInt32(tBox_itemPrice.Text);

                    qtyOthers++;

                    string totalItemPrice = "Rp" + (priceItemPrice * qtyOthers).ToString();

                    bool exist = false;

                    for (int i = 0; i < dtTabel.Rows.Count; i++)
                    {
                        if (dtTabel.Rows[i][0].ToString() == tBox_itemName.Text)
                        {
                            exist = true;
                            break;
                        }
                    }

                    if (exist)
                    {
                        for (int i = 0; i < dtTabel.Rows.Count; i++)
                        {
                            if (dtTabel.Rows[i][0].ToString() == tBox_itemName.Text)
                            {
                                dtTabel.Rows[i][1] = qtyOthers.ToString();
                                dtTabel.Rows[i][3] = totalItemPrice;
                            }
                        }
                    }
                    else
                    {
                        qtyOthers = 1;

                        totalItemPrice = "Rp" + (priceItemPrice * qtyOthers).ToString();

                        dtTabel.Rows.Add(tBox_itemName.Text, qtyOthers.ToString(), strPriceItemPrice, totalItemPrice);
                    }

                    hitungTotal();
                }
            }
            else
            {
                MessageBox.Show("Item name dan item price harus diisi", "Error");
            }
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            bool uploaded = false;

            string image = "";

            OpenFileDialog gambar = new OpenFileDialog();
            gambar.Filter = "Image Files (*.jpg, *.jpeg, *.png)|*.jpg;*.jpeg;*.png;";

            if (gambar.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                image = gambar.FileName;

                pBox_others.ImageLocation = image;

                uploaded = true;
            }
            else
            {
                MessageBox.Show("Gambar belum ter-upload. Format gambar: jpg/png/jpeg", "Fail");
            }

            if (uploaded)
            {
                tBox_itemName.Enabled = true;
                tBox_itemPrice.Enabled = true;
            }
        }

        private void hitungTotal()
        {
            int subTotal = 0;

            for (int i = 0; i < dtTabel.Rows.Count; i++)
            {
                subTotal += Convert.ToInt32(dtTabel.Rows[i][3].ToString().Substring(2));
            }

            tBox_subTotal.Text = "Rp" + subTotal.ToString("N");

            tBox_total.Text = "Rp" + (subTotal + (subTotal * 0.1)).ToString("N");    

            dgv_tabel.ClearSelection();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dgv_tabel.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih produk yang mau dihapus terlebih dahulu", "Error");
            }
            else 
            {
                int indexRow = dgv_tabel.CurrentCell.RowIndex;

                dtTabel.Rows.RemoveAt(indexRow);
            }

            hitungTotal();
        }

        private void tBox_itemPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tBox_itemName_TextChanged(object sender, EventArgs e)
        {
            if (tBox_itemName.Text != "" && tBox_itemPrice.Text != "")
            {
                btn_addOthers.Enabled = true;
            }
            else
            {
                btn_addOthers.Enabled = false;
            }
        }

        private void tBox_itemPrice_TextChanged(object sender, EventArgs e)
        {
            if (tBox_itemName.Text != "" && tBox_itemPrice.Text != "")
            {
                btn_addOthers.Enabled = true;
            }
            else
            {
                btn_addOthers.Enabled = false;
            }
        }
    }
}
