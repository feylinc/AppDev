﻿namespace TH14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.lb_type = new System.Windows.Forms.Label();
            this.lb_player = new System.Windows.Forms.Label();
            this.lb_team = new System.Windows.Forms.Label();
            this.lb_minute = new System.Windows.Forms.Label();
            this.dtp = new System.Windows.Forms.DateTimePicker();
            this.cb_teamAway = new System.Windows.Forms.ComboBox();
            this.lb_teamAway = new System.Windows.Forms.Label();
            this.lb_matchDate = new System.Windows.Forms.Label();
            this.btn_insert = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.cb_teamHome = new System.Windows.Forms.ComboBox();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.lb_teamHome = new System.Windows.Forms.Label();
            this.lb_matchID = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1167, 555);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(141, 48);
            this.btn_delete.TabIndex = 59;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(1026, 555);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(120, 48);
            this.btn_add.TabIndex = 58;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(1045, 477);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(263, 33);
            this.cb_type.TabIndex = 57;
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(1045, 412);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(263, 33);
            this.cb_player.TabIndex = 56;
            this.cb_player.SelectedIndexChanged += new System.EventHandler(this.cb_player_SelectedIndexChanged);
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(1045, 345);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(263, 33);
            this.cb_team.TabIndex = 55;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(1045, 278);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(263, 31);
            this.tb_minute.TabIndex = 54;
            // 
            // lb_type
            // 
            this.lb_type.AutoSize = true;
            this.lb_type.Location = new System.Drawing.Point(946, 480);
            this.lb_type.Name = "lb_type";
            this.lb_type.Size = new System.Drawing.Size(60, 25);
            this.lb_type.TabIndex = 53;
            this.lb_type.Text = "Type";
            // 
            // lb_player
            // 
            this.lb_player.AutoSize = true;
            this.lb_player.Location = new System.Drawing.Point(946, 415);
            this.lb_player.Name = "lb_player";
            this.lb_player.Size = new System.Drawing.Size(73, 25);
            this.lb_player.TabIndex = 52;
            this.lb_player.Text = "Player";
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Location = new System.Drawing.Point(946, 348);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(66, 25);
            this.lb_team.TabIndex = 51;
            this.lb_team.Text = "Team";
            // 
            // lb_minute
            // 
            this.lb_minute.AutoSize = true;
            this.lb_minute.Location = new System.Drawing.Point(946, 281);
            this.lb_minute.Name = "lb_minute";
            this.lb_minute.Size = new System.Drawing.Size(77, 25);
            this.lb_minute.TabIndex = 50;
            this.lb_minute.Text = "Minute";
            // 
            // dtp
            // 
            this.dtp.Location = new System.Drawing.Point(936, 44);
            this.dtp.Name = "dtp";
            this.dtp.Size = new System.Drawing.Size(418, 31);
            this.dtp.TabIndex = 49;
            // 
            // cb_teamAway
            // 
            this.cb_teamAway.FormattingEnabled = true;
            this.cb_teamAway.Location = new System.Drawing.Point(936, 115);
            this.cb_teamAway.Name = "cb_teamAway";
            this.cb_teamAway.Size = new System.Drawing.Size(290, 33);
            this.cb_teamAway.TabIndex = 48;
            this.cb_teamAway.SelectedIndexChanged += new System.EventHandler(this.cb_teamAway_SelectedIndexChanged);
            // 
            // lb_teamAway
            // 
            this.lb_teamAway.AutoSize = true;
            this.lb_teamAway.Location = new System.Drawing.Point(790, 118);
            this.lb_teamAway.Name = "lb_teamAway";
            this.lb_teamAway.Size = new System.Drawing.Size(124, 25);
            this.lb_teamAway.TabIndex = 47;
            this.lb_teamAway.Text = "Team Away";
            // 
            // lb_matchDate
            // 
            this.lb_matchDate.AutoSize = true;
            this.lb_matchDate.Location = new System.Drawing.Point(790, 49);
            this.lb_matchDate.Name = "lb_matchDate";
            this.lb_matchDate.Size = new System.Drawing.Size(122, 25);
            this.lb_matchDate.TabIndex = 46;
            this.lb_matchDate.Text = "Match Date";
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(1162, 674);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(146, 48);
            this.btn_insert.TabIndex = 45;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(36, 235);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 82;
            this.dgv.RowTemplate.Height = 33;
            this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv.Size = new System.Drawing.Size(851, 599);
            this.dgv.TabIndex = 44;
            // 
            // cb_teamHome
            // 
            this.cb_teamHome.FormattingEnabled = true;
            this.cb_teamHome.Location = new System.Drawing.Point(173, 118);
            this.cb_teamHome.Name = "cb_teamHome";
            this.cb_teamHome.Size = new System.Drawing.Size(263, 33);
            this.cb_teamHome.TabIndex = 43;
            this.cb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cb_teamHome_SelectedIndexChanged);
            // 
            // tb_matchID
            // 
            this.tb_matchID.Location = new System.Drawing.Point(173, 46);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.Size = new System.Drawing.Size(263, 31);
            this.tb_matchID.TabIndex = 42;
            // 
            // lb_teamHome
            // 
            this.lb_teamHome.AutoSize = true;
            this.lb_teamHome.Location = new System.Drawing.Point(31, 121);
            this.lb_teamHome.Name = "lb_teamHome";
            this.lb_teamHome.Size = new System.Drawing.Size(128, 25);
            this.lb_teamHome.TabIndex = 41;
            this.lb_teamHome.Text = "Team Home";
            // 
            // lb_matchID
            // 
            this.lb_matchID.AutoSize = true;
            this.lb_matchID.Location = new System.Drawing.Point(31, 49);
            this.lb_matchID.Name = "lb_matchID";
            this.lb_matchID.Size = new System.Drawing.Size(97, 25);
            this.lb_matchID.TabIndex = 40;
            this.lb_matchID.Text = "Match ID";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1384, 880);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.lb_type);
            this.Controls.Add(this.lb_player);
            this.Controls.Add(this.lb_team);
            this.Controls.Add(this.lb_minute);
            this.Controls.Add(this.dtp);
            this.Controls.Add(this.cb_teamAway);
            this.Controls.Add(this.lb_teamAway);
            this.Controls.Add(this.lb_matchDate);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.cb_teamHome);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.lb_teamHome);
            this.Controls.Add(this.lb_matchID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.Label lb_type;
        private System.Windows.Forms.Label lb_player;
        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.Label lb_minute;
        private System.Windows.Forms.DateTimePicker dtp;
        private System.Windows.Forms.ComboBox cb_teamAway;
        private System.Windows.Forms.Label lb_teamAway;
        private System.Windows.Forms.Label lb_matchDate;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.ComboBox cb_teamHome;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.Label lb_teamHome;
        private System.Windows.Forms.Label lb_matchID;
    }
}

