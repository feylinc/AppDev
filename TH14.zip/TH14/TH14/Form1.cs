﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TH14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection connect = new MySqlConnection("server = localhost; uid = root; pwd =  ; database = premier_league");
        MySqlCommand command;
        MySqlDataAdapter adapter;
        string query;

        DataTable dtTeamHome = new DataTable();
        DataTable dtTeamAway = new DataTable();
        DataTable dt = new DataTable();
        DataTable dtTeam = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable dtType = new DataTable();

        private void Form1_Load(object sender, EventArgs e)
        {
            connect.Open();

            query = "select team_name, team_id from team";
            command = new MySqlCommand(query, connect);

            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dtTeamHome);

            cb_teamHome.DataSource = dtTeamHome;
            cb_teamHome.DisplayMember = "team_name";
            cb_teamHome.ValueMember = "team_id";

            query = "select team_name, team_id from team";
            command = new MySqlCommand(query, connect);

            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dtTeamAway);

            cb_teamAway.DataSource = dtTeamAway;
            cb_teamAway.DisplayMember = "team_name";
            cb_teamAway.ValueMember = "team_id";

            query = "select type from dmatch where type = 'GO' or type = 'GP' or type = 'GW' group by 1";
            command = new MySqlCommand(query, connect);

            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dtType);

            cb_type.DataSource = dtType;
            cb_type.DisplayMember = "type";
            cb_type.ValueMember = "type";

            cb_teamHome.SelectedIndex = -1;
            cb_teamAway.SelectedIndex = -1;
            cb_team.SelectedIndex = -1;
            cb_type.SelectedIndex = -1;

            tb_matchID.Enabled = false;
        }

        private void cb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            code();
        }

        private void cb_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            code();
        }

        private void code()
        {
            if (cb_teamHome.SelectedItem != null && cb_teamAway.SelectedItem != null)
            {
                dtTeam.Clear();
                dt.Clear();
                cb_type.SelectedIndex = -1;
                tb_minute.Clear();

                if (cb_teamHome.SelectedValue.ToString() == cb_teamAway.SelectedValue.ToString())
                {
                    MessageBox.Show("Team home dan team away tidak boleh sama");
                }
                else
                { 
                    query = $"select team_name, team_id from team where team_id = '{cb_teamHome.SelectedValue}' or team_id = '{cb_teamAway.SelectedValue}'";
                    command = new MySqlCommand(query, connect);

                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtTeam);

                    cb_team.DataSource = dtTeam;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";

                    cb_team.SelectedIndex = -1;
              
                    query = $"select d.minute as Minute, t.team_name as Team, p.player_name as Player, d.type as Type from dmatch d join team t on d.team_id = t.team_id join player p on p.player_id = d.player_id join `match` m on d.match_id = m.match_id where m.team_home = '{cb_teamHome.SelectedValue}' and m.team_away = '{cb_teamAway.SelectedValue}' and referee_id = 'M002' and (type = 'GO' or type = 'GP' or type = 'GW');";
                    command = new MySqlCommand(query, connect);

                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dt);

                    dgv.DataSource = dt;
                    dgv.ClearSelection();

                    query = $"select match_id from `match` where team_home = '{cb_teamHome.SelectedValue}' and team_away = '{cb_teamAway.SelectedValue}' and referee_id = 'M002'";
                    command = new MySqlCommand(query, connect);

                    if (command.ExecuteScalar() == null)
                    {
                        tb_matchID.Text = "";
                    }
                    else
                    {
                        tb_matchID.Text = command.ExecuteScalar().ToString();
                    }

                    query = $"select match_date from `match` where match_id = '{tb_matchID.Text}'";
                    command = new MySqlCommand(query, connect);

                    string date;

                    if (command.ExecuteScalar() == null)
                    {
                        date = DateTime.Now.ToString(); 
                    }
                    else
                    {
                        date = command.ExecuteScalar().ToString();
                    }

                    DateTime dateTP = Convert.ToDateTime(date);
                    dtp.Value = dateTP;
                }
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtPlayer.Clear();

            query = $"select player_name, player_id from player where team_id = '{cb_team.SelectedValue}'";
            command = new MySqlCommand(query, connect);

            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dtPlayer);

            cb_player.DataSource = dtPlayer;
            cb_player.DisplayMember = "player_name";
            cb_player.ValueMember = "player_id";

            cb_player.SelectedIndex = -1;
        }


        private void cb_player_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count != 0)
            {
                int indexRow = dgv.CurrentCell.RowIndex;

                dt.Rows.RemoveAt(indexRow);
            }

            dgv.ClearSelection();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tb_minute.Text != "" && cb_team.SelectedItem != null && cb_player.SelectedItem != null && cb_type.SelectedItem != null)
            {
                dt.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);
            }
            else
            {
                MessageBox.Show("Minute, team, player, dan type harus terisi");
            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            if (tb_matchID.Text == "")
            {
                if (dt.Rows.Count != 0)
                {
                    string year = DateTime.Now.Year.ToString();
                    string month = DateTime.Now.Month.ToString();
                    string day = DateTime.Now.Day.ToString();

                    string date = $"{year}-{month}-{day}";

                    query = $"select count(m.match_id) from `match` m where left(m.match_id, 4) = {year};";
                    command = new MySqlCommand(query, connect);

                    int count = Convert.ToInt32(command.ExecuteScalar());

                    count += 1;

                    tb_matchID.Text = $"{year}{count.ToString("D3")}";

                    int countTeamHome = 0;
                    int countTeamAway = 0;

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (dt.Rows[i][1].ToString() == cb_teamHome.Text)
                        {
                            if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                            {
                                countTeamHome++;
                            }
                            else
                            {
                                countTeamAway++;
                            }
                        }
                        else if (dt.Rows[i][1].ToString() == cb_teamAway.Text)
                        {
                            if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                            {
                                countTeamAway++;
                            }
                            else
                            {
                                countTeamHome++;
                            }
                        }
                    }

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        query = $"select team_id from team where team_name = '{dt.Rows[i][1].ToString()}'";
                        command = new MySqlCommand(query, connect);

                        string teamID = command.ExecuteScalar().ToString();

                        query = $"select player_id from player where player_name = '{dt.Rows[i][2].ToString()}'";
                        command = new MySqlCommand(query, connect);

                        string playerID = command.ExecuteScalar().ToString();

                        query = $"insert into dmatch values ({tb_matchID.Text}, {dt.Rows[i][0]}, '{teamID}', '{playerID}', '{dt.Rows[i][3].ToString()}', 0)";
                        command = new MySqlCommand(query, connect);

                        command.ExecuteNonQuery();
                    }

                    query = $"insert into `match` values ({tb_matchID.Text}, '{date}', '{cb_teamHome.SelectedValue}', '{cb_teamAway.SelectedValue}', {countTeamHome}, {countTeamAway}, 'M002', 0)";
                    command = new MySqlCommand(query, connect);

                    command.ExecuteNonQuery();
                }
            }
            else
            {
                int countTeamHome = 0;
                int countTeamAway = 0;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][1].ToString() == cb_teamHome.Text)
                    {
                        if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                        {
                            countTeamHome++;
                        }
                        else
                        {
                            countTeamAway++;
                        }
                    }
                    else if (dt.Rows[i][1].ToString() == cb_teamAway.Text)
                    {
                        if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                        {
                            countTeamAway++;
                        }
                        else
                        {
                            countTeamHome++;
                        }
                    }
                }

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    query = $"select team_id from team where team_name = '{dt.Rows[i][1].ToString()}'";
                    command = new MySqlCommand(query, connect);

                    string teamID = command.ExecuteScalar().ToString();

                    query = $"select player_id from player where player_name = '{dt.Rows[i][2].ToString()}'";
                    command = new MySqlCommand(query, connect);

                    string playerID = command.ExecuteScalar().ToString();

                    query = $"insert into dmatch values ({tb_matchID.Text}, {dt.Rows[i][0]}, '{teamID}', '{playerID}', '{dt.Rows[i][3].ToString()}', 0)";
                    command = new MySqlCommand(query, connect);

                    command.ExecuteNonQuery();
                }

                //match_id pada tabel `match` adalah primary key, jadi tidak bisa insert match_id yang sudah pernah terbuat ke tabel `match`, hanya bisa diinsert ke dmatch
            }

        }
    }
}
