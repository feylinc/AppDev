﻿namespace TH03
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_UCBank = new System.Windows.Forms.Label();
            this.lb_username = new System.Windows.Forms.Label();
            this.lb_password = new System.Windows.Forms.Label();
            this.tBox_username = new System.Windows.Forms.TextBox();
            this.tBox_password = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_register = new System.Windows.Forms.Button();
            this.btn_register2 = new System.Windows.Forms.Button();
            this.lb_balance = new System.Windows.Forms.Label();
            this.lb_balanceRp = new System.Windows.Forms.Label();
            this.btn_logout = new System.Windows.Forms.Button();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.panel_afterLogin = new System.Windows.Forms.Panel();
            this.panel_withdraw = new System.Windows.Forms.Panel();
            this.tBox_inputWithdraw = new System.Windows.Forms.TextBox();
            this.btn_withdraw2 = new System.Windows.Forms.Button();
            this.lb_withdraw = new System.Windows.Forms.Label();
            this.panel_deposit = new System.Windows.Forms.Panel();
            this.tBox_inputDeposit = new System.Windows.Forms.TextBox();
            this.btn_deposit2 = new System.Windows.Forms.Button();
            this.lb_inputDeposit = new System.Windows.Forms.Label();
            this.panel_afterLogin.SuspendLayout();
            this.panel_withdraw.SuspendLayout();
            this.panel_deposit.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_UCBank
            // 
            this.lb_UCBank.AutoSize = true;
            this.lb_UCBank.Location = new System.Drawing.Point(60, 51);
            this.lb_UCBank.Name = "lb_UCBank";
            this.lb_UCBank.Size = new System.Drawing.Size(97, 25);
            this.lb_UCBank.TabIndex = 0;
            this.lb_UCBank.Text = "UC Bank";
            // 
            // lb_username
            // 
            this.lb_username.AutoSize = true;
            this.lb_username.Location = new System.Drawing.Point(70, 198);
            this.lb_username.Name = "lb_username";
            this.lb_username.Size = new System.Drawing.Size(122, 25);
            this.lb_username.TabIndex = 1;
            this.lb_username.Text = "Username: ";
            // 
            // lb_password
            // 
            this.lb_password.AutoSize = true;
            this.lb_password.Location = new System.Drawing.Point(70, 250);
            this.lb_password.Name = "lb_password";
            this.lb_password.Size = new System.Drawing.Size(118, 25);
            this.lb_password.TabIndex = 2;
            this.lb_password.Text = "Password: ";
            // 
            // tBox_username
            // 
            this.tBox_username.Location = new System.Drawing.Point(198, 195);
            this.tBox_username.Name = "tBox_username";
            this.tBox_username.Size = new System.Drawing.Size(175, 31);
            this.tBox_username.TabIndex = 3;
            // 
            // tBox_password
            // 
            this.tBox_password.Location = new System.Drawing.Point(198, 247);
            this.tBox_password.Name = "tBox_password";
            this.tBox_password.Size = new System.Drawing.Size(175, 31);
            this.tBox_password.TabIndex = 4;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(173, 313);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(112, 52);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_register
            // 
            this.btn_register.Location = new System.Drawing.Point(173, 382);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(112, 51);
            this.btn_register.TabIndex = 6;
            this.btn_register.Text = "Register";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // btn_register2
            // 
            this.btn_register2.Location = new System.Drawing.Point(173, 313);
            this.btn_register2.Name = "btn_register2";
            this.btn_register2.Size = new System.Drawing.Size(112, 51);
            this.btn_register2.TabIndex = 7;
            this.btn_register2.Text = "Register";
            this.btn_register2.UseVisualStyleBackColor = true;
            this.btn_register2.Click += new System.EventHandler(this.btn_register2_Click);
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Location = new System.Drawing.Point(10, 29);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(90, 25);
            this.lb_balance.TabIndex = 8;
            this.lb_balance.Text = "Balance";
            // 
            // lb_balanceRp
            // 
            this.lb_balanceRp.AutoSize = true;
            this.lb_balanceRp.Location = new System.Drawing.Point(106, 21);
            this.lb_balanceRp.Name = "lb_balanceRp";
            this.lb_balanceRp.Size = new System.Drawing.Size(81, 25);
            this.lb_balanceRp.TabIndex = 9;
            this.lb_balanceRp.Text = "Rp0,00";
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(316, 126);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(118, 51);
            this.btn_logout.TabIndex = 10;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(111, 89);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(140, 51);
            this.btn_deposit.TabIndex = 11;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Location = new System.Drawing.Point(111, 160);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(140, 51);
            this.btn_withdraw.TabIndex = 12;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // panel_afterLogin
            // 
            this.panel_afterLogin.Controls.Add(this.panel_withdraw);
            this.panel_afterLogin.Controls.Add(this.btn_withdraw);
            this.panel_afterLogin.Controls.Add(this.btn_deposit);
            this.panel_afterLogin.Controls.Add(this.lb_balanceRp);
            this.panel_afterLogin.Controls.Add(this.lb_balance);
            this.panel_afterLogin.Location = new System.Drawing.Point(109, 210);
            this.panel_afterLogin.Name = "panel_afterLogin";
            this.panel_afterLogin.Size = new System.Drawing.Size(508, 277);
            this.panel_afterLogin.TabIndex = 13;
            this.panel_afterLogin.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_afterLogin_Paint);
            // 
            // panel_withdraw
            // 
            this.panel_withdraw.Controls.Add(this.tBox_inputWithdraw);
            this.panel_withdraw.Controls.Add(this.btn_withdraw2);
            this.panel_withdraw.Controls.Add(this.lb_withdraw);
            this.panel_withdraw.Location = new System.Drawing.Point(0, 66);
            this.panel_withdraw.Name = "panel_withdraw";
            this.panel_withdraw.Size = new System.Drawing.Size(269, 225);
            this.panel_withdraw.TabIndex = 18;
            // 
            // tBox_inputWithdraw
            // 
            this.tBox_inputWithdraw.Location = new System.Drawing.Point(48, 79);
            this.tBox_inputWithdraw.Name = "tBox_inputWithdraw";
            this.tBox_inputWithdraw.Size = new System.Drawing.Size(178, 31);
            this.tBox_inputWithdraw.TabIndex = 15;
            // 
            // btn_withdraw2
            // 
            this.btn_withdraw2.Location = new System.Drawing.Point(71, 134);
            this.btn_withdraw2.Name = "btn_withdraw2";
            this.btn_withdraw2.Size = new System.Drawing.Size(137, 48);
            this.btn_withdraw2.TabIndex = 16;
            this.btn_withdraw2.Text = "Withdraw";
            this.btn_withdraw2.UseVisualStyleBackColor = true;
            this.btn_withdraw2.Click += new System.EventHandler(this.btn_withdraw2_Click);
            // 
            // lb_withdraw
            // 
            this.lb_withdraw.AutoSize = true;
            this.lb_withdraw.Location = new System.Drawing.Point(11, 32);
            this.lb_withdraw.Name = "lb_withdraw";
            this.lb_withdraw.Size = new System.Drawing.Size(256, 25);
            this.lb_withdraw.TabIndex = 14;
            this.lb_withdraw.Text = "Input Withdrawal Amount:";
            // 
            // panel_deposit
            // 
            this.panel_deposit.Controls.Add(this.tBox_inputDeposit);
            this.panel_deposit.Controls.Add(this.btn_deposit2);
            this.panel_deposit.Controls.Add(this.lb_inputDeposit);
            this.panel_deposit.Location = new System.Drawing.Point(126, 197);
            this.panel_deposit.Name = "panel_deposit";
            this.panel_deposit.Size = new System.Drawing.Size(247, 310);
            this.panel_deposit.TabIndex = 17;
            // 
            // tBox_inputDeposit
            // 
            this.tBox_inputDeposit.Location = new System.Drawing.Point(32, 79);
            this.tBox_inputDeposit.Name = "tBox_inputDeposit";
            this.tBox_inputDeposit.Size = new System.Drawing.Size(178, 31);
            this.tBox_inputDeposit.TabIndex = 15;
            // 
            // btn_deposit2
            // 
            this.btn_deposit2.Location = new System.Drawing.Point(55, 134);
            this.btn_deposit2.Name = "btn_deposit2";
            this.btn_deposit2.Size = new System.Drawing.Size(137, 48);
            this.btn_deposit2.TabIndex = 16;
            this.btn_deposit2.Text = "Deposit";
            this.btn_deposit2.UseVisualStyleBackColor = true;
            this.btn_deposit2.Click += new System.EventHandler(this.btn_deposit2_Click);
            // 
            // lb_inputDeposit
            // 
            this.lb_inputDeposit.AutoSize = true;
            this.lb_inputDeposit.Location = new System.Drawing.Point(11, 32);
            this.lb_inputDeposit.Name = "lb_inputDeposit";
            this.lb_inputDeposit.Size = new System.Drawing.Size(223, 25);
            this.lb_inputDeposit.TabIndex = 14;
            this.lb_inputDeposit.Text = "Input Deposit Amount:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 538);
            this.Controls.Add(this.panel_afterLogin);
            this.Controls.Add(this.btn_logout);
            this.Controls.Add(this.btn_register2);
            this.Controls.Add(this.btn_register);
            this.Controls.Add(this.panel_deposit);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.tBox_password);
            this.Controls.Add(this.tBox_username);
            this.Controls.Add(this.lb_password);
            this.Controls.Add(this.lb_username);
            this.Controls.Add(this.lb_UCBank);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_afterLogin.ResumeLayout(false);
            this.panel_afterLogin.PerformLayout();
            this.panel_withdraw.ResumeLayout(false);
            this.panel_withdraw.PerformLayout();
            this.panel_deposit.ResumeLayout(false);
            this.panel_deposit.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_UCBank;
        private System.Windows.Forms.Label lb_username;
        private System.Windows.Forms.Label lb_password;
        private System.Windows.Forms.TextBox tBox_username;
        private System.Windows.Forms.TextBox tBox_password;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.Button btn_register2;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Label lb_balanceRp;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Panel panel_afterLogin;
        private System.Windows.Forms.Label lb_inputDeposit;
        private System.Windows.Forms.TextBox tBox_inputDeposit;
        private System.Windows.Forms.Button btn_deposit2;
        private System.Windows.Forms.Panel panel_deposit;
        private System.Windows.Forms.Panel panel_withdraw;
        private System.Windows.Forms.TextBox tBox_inputWithdraw;
        private System.Windows.Forms.Button btn_withdraw2;
        private System.Windows.Forms.Label lb_withdraw;
    }
}

