﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class Form1 : Form
    {
        List<User> users = new List<User>();

        int index = 0;

        public Form1()
        {
            InitializeComponent();

            lb_UCBank.Font = new Font(lb_UCBank.Font.FontFamily, 20);
            lb_balanceRp.Font = new Font(lb_balanceRp.Font.FontFamily, 12);

            btn_register2.Visible = false;
            btn_logout.Visible = false;
            panel_afterLogin.Visible = false;
            panel_deposit.Visible = false;
            panel_withdraw.Visible = false;
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string inputUsername = tBox_username.Text;
            string inputPassword = tBox_password.Text;

            bool cek = false;

            for (int i = 0; i < users.Count; i++)
            {
                if (users[i].username == inputUsername && users[i].password == inputPassword)
                {
                    index = i;

                    cek = true;
                    break;
                }
            }

            if (cek)
            {
                MessageBox.Show("Login successful");

                panel_afterLogin.Visible = true;
                btn_logout.Visible = true;
                lb_username.Visible = false;
                lb_password.Visible = false;
                tBox_username.Visible = false;
                tBox_password.Visible = false;
            }
            else
            {
                MessageBox.Show("Username and password not found");
            }

            tBox_username.Clear();
            tBox_password.Clear();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            btn_login.Visible = false;
            btn_register.Visible = false;
            btn_register2.Visible = true;

            tBox_username.Clear();
            tBox_password.Clear();
        }

        private void btn_register2_Click(object sender, EventArgs e)
        {
            string inputUsername = tBox_username.Text;
            string inputPassword = tBox_password.Text;

            bool cek = false;

            foreach (User user in users)
            {
                if (user.username == inputUsername)
                {
                    cek = true;
                    break;
                }
            }

            if (cek)
            {
                MessageBox.Show("Username has been used");
            }
            else
            {
                users.Add(new User(inputUsername, inputPassword));

                MessageBox.Show("Register successful");

                btn_login.Visible = true;
                btn_register.Visible = true;
                btn_register2.Visible = false;
            }

            tBox_username.Clear();
            tBox_password.Clear();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log out berhasil");

            btn_login.Visible = true;
            btn_register.Visible = true;
            panel_afterLogin.Visible = false;
            lb_username.Visible = true;
            lb_password.Visible = true;
            tBox_username.Visible = true;
            tBox_password.Visible = true;
            btn_logout.Visible = false;
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            panel_afterLogin.Visible = false;
            panel_deposit.Visible = true;
            btn_login.Visible = false;
            btn_register.Visible = false;
        }

        private void btn_deposit2_Click(object sender, EventArgs e)
        {
            users[index].Deposit(tBox_inputDeposit);

            tBox_inputDeposit.Clear();

            panel_afterLogin.Visible = true;
            panel_deposit.Visible = false;
        }

        private void panel_afterLogin_Paint(object sender, PaintEventArgs e)
        {
            users[index].Balance(lb_balanceRp);
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            panel_withdraw.Visible = true;
        }

        private void btn_withdraw2_Click(object sender, EventArgs e)
        {
            users[index].Withdraw(tBox_inputWithdraw);

            tBox_inputWithdraw.Clear();

            panel_afterLogin.Visible = true;
            panel_deposit.Visible = false;
            panel_withdraw.Visible = false;
        }
    }

    public class User
    {
        public string username;
        public string password;
        public int balance;

        public User(string inputUsername, string inputPassword)
        {
            username = inputUsername;
            password = inputPassword;
            balance = 0;
        }

        public void Deposit(TextBox tBox_inputDeposit)
        {
            bool valid = false;

            foreach (char a in tBox_inputDeposit.Text)
            {
                if (char.IsNumber(a))
                {
                    valid = true;
                }
            }

            if (valid)
            {
                if (Convert.ToInt32(tBox_inputDeposit.Text) < 1)
                {
                    MessageBox.Show("Deposit amount can't be less than 1");
                }
                else
                {
                    balance += Convert.ToInt32(tBox_inputDeposit.Text);

                    MessageBox.Show("Successfully add deposit");
                }
            }
            else
            {
                MessageBox.Show("Invalid input");
            }
        }

        public void Withdraw(TextBox tBox_inputWithdraw)
        {
            bool valid = false;

            foreach (char a in tBox_inputWithdraw.Text)
            {
                if (char.IsNumber(a))
                {
                    valid = true;
                }
            }

            if (valid)
            {
                if (Convert.ToInt32(tBox_inputWithdraw.Text) < 1)
                {
                    MessageBox.Show("Withdraw amount can't be less than 1");
                }
                else if (Convert.ToInt32(tBox_inputWithdraw.Text) <= balance)
                {
                    balance -= Convert.ToInt32(tBox_inputWithdraw.Text);

                    MessageBox.Show("Successfully withdraw");
                }
                else
                {
                    MessageBox.Show("Withdraw failed. Not enough balance");
                }
            }
            else
            {
                MessageBox.Show("Invalid input");
            }
        }

        public void Balance(Label lb_balanceRp)
        {
            lb_balanceRp.Text = "Rp" + balance.ToString("N");
        }
    }
}



