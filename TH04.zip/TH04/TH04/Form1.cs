﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH04
{
    public partial class Form1 : Form
    {
        List<Team> teams = new List<Team>();

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            teams = new List<Team>();

            Team team = new Team("Manchester United", "England", "Manchester");
            team.AddPlayer("David De Gea", "01", "GK");
            team.AddPlayer("Victor Lindelof", "02", "DF");
            team.AddPlayer("Phil Jones", "04", "DF");
            team.AddPlayer("Harry Maguire", "05", "DF");
            team.AddPlayer("Lisandro Martinez", "06", "DF");
            team.AddPlayer("Bruno Fernandez", "08", "MF");
            team.AddPlayer("Anthony Martial", "09", "FW");
            team.AddPlayer("Marcus Rashford", "10", "FW");
            team.AddPlayer("Tyrell Malacia", "12", "DF");
            team.AddPlayer("Christian Eriksen", "14", "MF");
            team.AddPlayer("Casemiro", "18", "MF");
            teams.Add(team);

            team = new Team("Chelsea", "England", "Fulham");
            team.AddPlayer("Kepa Arrizabalaga", "01", "GK");
            team.AddPlayer("Benoît Badiashile", "04", "DF");
            team.AddPlayer("Enzo Fernández", "05", "MF");
            team.AddPlayer("Thiago Silva", "06", "DF");
            team.AddPlayer("N'Golo Kanté", "07", "MF");
            team.AddPlayer("Mateo Kovačić", "08", "MF");
            team.AddPlayer("Pierre-Emerick Aubameyang", "09", "FW");
            team.AddPlayer("Christian Pulisic", "10", "MF");
            team.AddPlayer("João Félix", "11", "FW");
            team.AddPlayer("Ruben Loftus-Cheek", "12", "MF");
            team.AddPlayer("Raheem Sterling", "17", "MF");
            teams.Add(team);

            team = new Team("Bayern Munich", "Germany", "Munich");
            team.AddPlayer("Manuel Neuer", "01", "GK");
            team.AddPlayer("Dayot Upamecano", "02", "DF");
            team.AddPlayer("Matthijs de Ligt", "04", "DF");
            team.AddPlayer("Benjamin Pavard", "05", "DF");
            team.AddPlayer("Joshua Kimmich", "06", "MF");
            team.AddPlayer("Serge Gnabry", "07", "FW");
            team.AddPlayer("Leon Goretzka", "08", "MF");
            team.AddPlayer("Leroy Sané", "10", "FW");
            team.AddPlayer("Thomas Müller ", "25", "FW");
            team.AddPlayer("Paul Wanner", "14", "MF");
            team.AddPlayer("Lucas Hernandez", "21", "DF");
            teams.Add(team);

            InitialCountry();
        }

        private void InitialCountry()
        {
            foreach (Team team in teams)
            {
                if (!cmbBox_country.Items.Contains(team.teamCountry))
                {
                    cmbBox_country.Items.Add(team.teamCountry);
                }
            }
        }

        private void cmbBox_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbBox_team.Items.Clear();

            foreach (Team team in teams)
            {
                if (team.teamCountry == cmbBox_country.SelectedItem.ToString())
                {
                    cmbBox_team.Items.Add(team.teamName);
                }
            }
        }

        private void cmbBox_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox_soccerTeamList.Items.Clear();

            foreach (Team team in teams)
            {
                if (team.teamName == cmbBox_team.SelectedItem.ToString())
                {
                    foreach (Player player in team.Players)
                    {
                        listBox_soccerTeamList.Items.Add($"({player.playerNum}) {player.playerName}, {player.playerPos}");
                    }
                }
            }
        }

        private void btn_tAdd_Click(object sender, EventArgs e)
        {
            if (tBox_tName.Text != "" && tBox_tCountry.Text != "" && tBox_tCity.Text != "")
            {
                bool exist = false;

                foreach (Team team in teams)
                {
                    if (team.teamCountry == tBox_tCountry.Text && team.teamName == tBox_tName.Text)
                    {
                        exist = true;
                        break;
                    }
                }

                if (!exist)
                {
                    Team team = new Team(tBox_tName.Text, tBox_tCountry.Text, tBox_tCity.Text);
                    teams.Add(team);

                    if (!cmbBox_country.Items.Contains(team.teamCountry))
                    {
                        cmbBox_country.Items.Add(team.teamCountry);
                    }

                    if (cmbBox_country.SelectedItem != null && team.teamCountry == cmbBox_country.SelectedItem.ToString())
                    {
                        cmbBox_team.Items.Add(team.teamName);
                    }
                }
                else
                {
                    MessageBox.Show("Team already exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("All fields need to be filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            tBox_tName.Clear();
            tBox_tCountry.Clear();
            tBox_tCity.Clear();          
        }

        private void btn_pAdd_Click(object sender, EventArgs e)
        {
            if (tBox_pName.Text != "" && tBox_pNumber.Text != "" && cmbBox_pPosition.SelectedItem != null)
            {
                bool isNumber = false;

                foreach (char a in tBox_pNumber.Text)
                {
                    if (char.IsNumber(a))
                    {
                        isNumber = true;
                    }
                }

                if (isNumber)
                {
                    foreach (Team team in teams)
                    {
                        if (cmbBox_country.SelectedItem.ToString() == team.teamCountry && cmbBox_team.SelectedItem.ToString() == team.teamName)
                        {
                            bool exist = false;

                            foreach (Player player in team.Players)
                            {
                                if (player.playerNum == tBox_pNumber.Text)
                                {
                                    MessageBox.Show("Player with same number already exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                                    exist = true;
                                    break;
                                }
                            }

                            if (!exist)
                            {
                                team.AddPlayer(tBox_pName.Text, tBox_pNumber.Text, cmbBox_pPosition.SelectedItem.ToString());

                                listBox_soccerTeamList.Items.Clear();

                                foreach (Player player in team.Players)
                                {
                                    listBox_soccerTeamList.Items.Add($"({player.playerNum}) {player.playerName}, {player.playerPos}");
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Player number input is invalid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                } 
            }
            else
            {
                MessageBox.Show("All fields need to be filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            tBox_pName.Clear();
            tBox_pNumber.Clear();
            cmbBox_pPosition.SelectedItem = null;
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            foreach (Team team in teams)
            {
                if (team.teamName == cmbBox_team.SelectedItem.ToString())
                {
                    if (team.Players.Count > 11)
                    {
                        foreach (Player player in team.Players)
                        {
                            if (listBox_soccerTeamList.SelectedItem.ToString() == $"({player.playerNum}) {player.playerName}, {player.playerPos}")
                            {
                                team.Players.Remove(player);
                                break;
                            }
                        }

                        listBox_soccerTeamList.Items.Remove(listBox_soccerTeamList.SelectedItem.ToString());
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Unable to remove player if the players are less than or equal to 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }                  
                }
            }
        }
    }

    public class Team
    {
        public string teamName;
        public string teamCountry;
        public string teamCity;
        public List<Player> Players;

        public Team(string namaTim, string namaNegara, string namaKota)
        {
            teamName = namaTim;
            teamCountry = namaNegara;
            teamCity = namaKota;
            Players = new List<Player>(); 
        }

        public void AddPlayer(string namaPemain, string nomorPemain, string posisiPemain)
        {
            Players.Add(new Player(namaPemain, nomorPemain, posisiPemain));
        }
    }

    public class Player
    {
        public string playerName;
        public string playerNum;
        public string playerPos;

        public Player(string namaPemain, string nomorPemain, string posisiPemain)
        {
            playerName = namaPemain;
            playerNum = nomorPemain;
            playerPos = posisiPemain;
        }
    }
}
