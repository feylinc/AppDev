﻿namespace TH04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_soccerTeamList = new System.Windows.Forms.Label();
            this.lb_chooseCountry = new System.Windows.Forms.Label();
            this.lb_chooseTeam = new System.Windows.Forms.Label();
            this.cmbBox_country = new System.Windows.Forms.ComboBox();
            this.cmbBox_team = new System.Windows.Forms.ComboBox();
            this.listBox_soccerTeamList = new System.Windows.Forms.ListBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.tBox_tName = new System.Windows.Forms.TextBox();
            this.tBox_tCountry = new System.Windows.Forms.TextBox();
            this.tBox_tCity = new System.Windows.Forms.TextBox();
            this.lb_tName = new System.Windows.Forms.Label();
            this.lb_tCountry = new System.Windows.Forms.Label();
            this.lb_tCity = new System.Windows.Forms.Label();
            this.lb_addingTeam = new System.Windows.Forms.Label();
            this.btn_tAdd = new System.Windows.Forms.Button();
            this.btn_pAdd = new System.Windows.Forms.Button();
            this.lb_addingPlayers = new System.Windows.Forms.Label();
            this.lb_pPosition = new System.Windows.Forms.Label();
            this.lb_pNumber = new System.Windows.Forms.Label();
            this.lb_pName = new System.Windows.Forms.Label();
            this.tBox_pNumber = new System.Windows.Forms.TextBox();
            this.tBox_pName = new System.Windows.Forms.TextBox();
            this.cmbBox_pPosition = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lb_soccerTeamList
            // 
            this.lb_soccerTeamList.AutoSize = true;
            this.lb_soccerTeamList.Location = new System.Drawing.Point(47, 67);
            this.lb_soccerTeamList.Name = "lb_soccerTeamList";
            this.lb_soccerTeamList.Size = new System.Drawing.Size(179, 25);
            this.lb_soccerTeamList.TabIndex = 0;
            this.lb_soccerTeamList.Text = "Soccer Team List";
            // 
            // lb_chooseCountry
            // 
            this.lb_chooseCountry.AutoSize = true;
            this.lb_chooseCountry.Location = new System.Drawing.Point(47, 134);
            this.lb_chooseCountry.Name = "lb_chooseCountry";
            this.lb_chooseCountry.Size = new System.Drawing.Size(173, 25);
            this.lb_chooseCountry.TabIndex = 1;
            this.lb_chooseCountry.Text = "Choose Country:";
            // 
            // lb_chooseTeam
            // 
            this.lb_chooseTeam.AutoSize = true;
            this.lb_chooseTeam.Location = new System.Drawing.Point(47, 188);
            this.lb_chooseTeam.Name = "lb_chooseTeam";
            this.lb_chooseTeam.Size = new System.Drawing.Size(152, 25);
            this.lb_chooseTeam.TabIndex = 2;
            this.lb_chooseTeam.Text = "Choose Team:";
            // 
            // cmbBox_country
            // 
            this.cmbBox_country.FormattingEnabled = true;
            this.cmbBox_country.Location = new System.Drawing.Point(226, 131);
            this.cmbBox_country.Name = "cmbBox_country";
            this.cmbBox_country.Size = new System.Drawing.Size(199, 33);
            this.cmbBox_country.TabIndex = 3;
            this.cmbBox_country.SelectedIndexChanged += new System.EventHandler(this.cmbBox_country_SelectedIndexChanged);
            // 
            // cmbBox_team
            // 
            this.cmbBox_team.FormattingEnabled = true;
            this.cmbBox_team.Location = new System.Drawing.Point(226, 185);
            this.cmbBox_team.Name = "cmbBox_team";
            this.cmbBox_team.Size = new System.Drawing.Size(199, 33);
            this.cmbBox_team.TabIndex = 4;
            this.cmbBox_team.SelectedIndexChanged += new System.EventHandler(this.cmbBox_team_SelectedIndexChanged);
            // 
            // listBox_soccerTeamList
            // 
            this.listBox_soccerTeamList.FormattingEnabled = true;
            this.listBox_soccerTeamList.ItemHeight = 25;
            this.listBox_soccerTeamList.Location = new System.Drawing.Point(52, 262);
            this.listBox_soccerTeamList.Name = "listBox_soccerTeamList";
            this.listBox_soccerTeamList.Size = new System.Drawing.Size(373, 254);
            this.listBox_soccerTeamList.TabIndex = 5;
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(52, 546);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(110, 46);
            this.btn_remove.TabIndex = 6;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // tBox_tName
            // 
            this.tBox_tName.Location = new System.Drawing.Point(629, 128);
            this.tBox_tName.Name = "tBox_tName";
            this.tBox_tName.Size = new System.Drawing.Size(204, 31);
            this.tBox_tName.TabIndex = 7;
            // 
            // tBox_tCountry
            // 
            this.tBox_tCountry.Location = new System.Drawing.Point(629, 185);
            this.tBox_tCountry.Name = "tBox_tCountry";
            this.tBox_tCountry.Size = new System.Drawing.Size(204, 31);
            this.tBox_tCountry.TabIndex = 8;
            // 
            // tBox_tCity
            // 
            this.tBox_tCity.Location = new System.Drawing.Point(629, 239);
            this.tBox_tCity.Name = "tBox_tCity";
            this.tBox_tCity.Size = new System.Drawing.Size(204, 31);
            this.tBox_tCity.TabIndex = 9;
            // 
            // lb_tName
            // 
            this.lb_tName.AutoSize = true;
            this.lb_tName.Location = new System.Drawing.Point(466, 134);
            this.lb_tName.Name = "lb_tName";
            this.lb_tName.Size = new System.Drawing.Size(134, 25);
            this.lb_tName.TabIndex = 10;
            this.lb_tName.Text = "Team Name:";
            // 
            // lb_tCountry
            // 
            this.lb_tCountry.AutoSize = true;
            this.lb_tCountry.Location = new System.Drawing.Point(466, 188);
            this.lb_tCountry.Name = "lb_tCountry";
            this.lb_tCountry.Size = new System.Drawing.Size(153, 25);
            this.lb_tCountry.TabIndex = 11;
            this.lb_tCountry.Text = "Team Country:";
            // 
            // lb_tCity
            // 
            this.lb_tCity.AutoSize = true;
            this.lb_tCity.Location = new System.Drawing.Point(466, 242);
            this.lb_tCity.Name = "lb_tCity";
            this.lb_tCity.Size = new System.Drawing.Size(115, 25);
            this.lb_tCity.TabIndex = 12;
            this.lb_tCity.Text = "Team City:";
            // 
            // lb_addingTeam
            // 
            this.lb_addingTeam.AutoSize = true;
            this.lb_addingTeam.Location = new System.Drawing.Point(624, 67);
            this.lb_addingTeam.Name = "lb_addingTeam";
            this.lb_addingTeam.Size = new System.Drawing.Size(139, 25);
            this.lb_addingTeam.TabIndex = 13;
            this.lb_addingTeam.Text = "Adding Team";
            // 
            // btn_tAdd
            // 
            this.btn_tAdd.Location = new System.Drawing.Point(629, 301);
            this.btn_tAdd.Name = "btn_tAdd";
            this.btn_tAdd.Size = new System.Drawing.Size(84, 46);
            this.btn_tAdd.TabIndex = 14;
            this.btn_tAdd.Text = "Add";
            this.btn_tAdd.UseVisualStyleBackColor = true;
            this.btn_tAdd.Click += new System.EventHandler(this.btn_tAdd_Click);
            // 
            // btn_pAdd
            // 
            this.btn_pAdd.Location = new System.Drawing.Point(1052, 301);
            this.btn_pAdd.Name = "btn_pAdd";
            this.btn_pAdd.Size = new System.Drawing.Size(84, 46);
            this.btn_pAdd.TabIndex = 22;
            this.btn_pAdd.Text = "Add";
            this.btn_pAdd.UseVisualStyleBackColor = true;
            this.btn_pAdd.Click += new System.EventHandler(this.btn_pAdd_Click);
            // 
            // lb_addingPlayers
            // 
            this.lb_addingPlayers.AutoSize = true;
            this.lb_addingPlayers.Location = new System.Drawing.Point(1047, 67);
            this.lb_addingPlayers.Name = "lb_addingPlayers";
            this.lb_addingPlayers.Size = new System.Drawing.Size(157, 25);
            this.lb_addingPlayers.TabIndex = 21;
            this.lb_addingPlayers.Text = "Adding Players";
            // 
            // lb_pPosition
            // 
            this.lb_pPosition.AutoSize = true;
            this.lb_pPosition.Location = new System.Drawing.Point(880, 245);
            this.lb_pPosition.Name = "lb_pPosition";
            this.lb_pPosition.Size = new System.Drawing.Size(162, 25);
            this.lb_pPosition.TabIndex = 20;
            this.lb_pPosition.Text = "Player Position:";
            // 
            // lb_pNumber
            // 
            this.lb_pNumber.AutoSize = true;
            this.lb_pNumber.Location = new System.Drawing.Point(880, 188);
            this.lb_pNumber.Name = "lb_pNumber";
            this.lb_pNumber.Size = new System.Drawing.Size(160, 25);
            this.lb_pNumber.TabIndex = 19;
            this.lb_pNumber.Text = "Player Number:";
            // 
            // lb_pName
            // 
            this.lb_pName.AutoSize = true;
            this.lb_pName.Location = new System.Drawing.Point(880, 134);
            this.lb_pName.Name = "lb_pName";
            this.lb_pName.Size = new System.Drawing.Size(141, 25);
            this.lb_pName.TabIndex = 18;
            this.lb_pName.Text = "Player Name:";
            // 
            // tBox_pNumber
            // 
            this.tBox_pNumber.Location = new System.Drawing.Point(1052, 185);
            this.tBox_pNumber.Name = "tBox_pNumber";
            this.tBox_pNumber.Size = new System.Drawing.Size(204, 31);
            this.tBox_pNumber.TabIndex = 16;
            // 
            // tBox_pName
            // 
            this.tBox_pName.Location = new System.Drawing.Point(1052, 128);
            this.tBox_pName.Name = "tBox_pName";
            this.tBox_pName.Size = new System.Drawing.Size(204, 31);
            this.tBox_pName.TabIndex = 15;
            // 
            // cmbBox_pPosition
            // 
            this.cmbBox_pPosition.FormattingEnabled = true;
            this.cmbBox_pPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cmbBox_pPosition.Location = new System.Drawing.Point(1052, 242);
            this.cmbBox_pPosition.Name = "cmbBox_pPosition";
            this.cmbBox_pPosition.Size = new System.Drawing.Size(204, 33);
            this.cmbBox_pPosition.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1407, 655);
            this.Controls.Add(this.cmbBox_pPosition);
            this.Controls.Add(this.btn_pAdd);
            this.Controls.Add(this.lb_addingPlayers);
            this.Controls.Add(this.lb_pPosition);
            this.Controls.Add(this.lb_pNumber);
            this.Controls.Add(this.lb_pName);
            this.Controls.Add(this.tBox_pNumber);
            this.Controls.Add(this.tBox_pName);
            this.Controls.Add(this.btn_tAdd);
            this.Controls.Add(this.lb_addingTeam);
            this.Controls.Add(this.lb_tCity);
            this.Controls.Add(this.lb_tCountry);
            this.Controls.Add(this.lb_tName);
            this.Controls.Add(this.tBox_tCity);
            this.Controls.Add(this.tBox_tCountry);
            this.Controls.Add(this.tBox_tName);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.listBox_soccerTeamList);
            this.Controls.Add(this.cmbBox_team);
            this.Controls.Add(this.cmbBox_country);
            this.Controls.Add(this.lb_chooseTeam);
            this.Controls.Add(this.lb_chooseCountry);
            this.Controls.Add(this.lb_soccerTeamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_soccerTeamList;
        private System.Windows.Forms.Label lb_chooseCountry;
        private System.Windows.Forms.Label lb_chooseTeam;
        private System.Windows.Forms.ComboBox cmbBox_country;
        private System.Windows.Forms.ComboBox cmbBox_team;
        private System.Windows.Forms.ListBox listBox_soccerTeamList;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.TextBox tBox_tName;
        private System.Windows.Forms.TextBox tBox_tCountry;
        private System.Windows.Forms.TextBox tBox_tCity;
        private System.Windows.Forms.Label lb_tName;
        private System.Windows.Forms.Label lb_tCountry;
        private System.Windows.Forms.Label lb_tCity;
        private System.Windows.Forms.Label lb_addingTeam;
        private System.Windows.Forms.Button btn_tAdd;
        private System.Windows.Forms.Button btn_pAdd;
        private System.Windows.Forms.Label lb_addingPlayers;
        private System.Windows.Forms.Label lb_pPosition;
        private System.Windows.Forms.Label lb_pNumber;
        private System.Windows.Forms.Label lb_pName;
        private System.Windows.Forms.TextBox tBox_pNumber;
        private System.Windows.Forms.TextBox tBox_pName;
        private System.Windows.Forms.ComboBox cmbBox_pPosition;
    }
}

