﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05
{
    public partial class Form1 : Form
    {
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.SkyBlue;

            Button btnAddP = new Button();
            btnAddP.Text = "Add Product";
            btnAddP.Size = new Size(60, 50);
            btnAddP.Location = new Point(180, 410);
            btnAddP.BackColor = Color.LightGreen;
            btnAddP.ForeColor = Color.Black;
            btnAddP.Click += new EventHandler(btnClick);

            Button btnEditP = new Button();
            btnEditP.Text = "Edit Product";
            btnEditP.Size = new Size(60, 50);
            btnEditP.Location = new Point(240, 410);
            btnEditP.BackColor = Color.Yellow;
            btnEditP.ForeColor = Color.Black;
            btnEditP.Click += new EventHandler(btnClick);

            Button btnRemoveP = new Button();
            btnRemoveP.Text = "Remove Product";
            btnRemoveP.Size = new Size(60, 50);
            btnRemoveP.Location = new Point(300, 410);
            btnRemoveP.BackColor = Color.Red;
            btnRemoveP.ForeColor = Color.Black;
            btnRemoveP.Click += new EventHandler(btnClick);

            this.Controls.Add(btnAddP);
            this.Controls.Add(btnEditP);
            this.Controls.Add(btnRemoveP);

            Button btnAddC = new Button();
            btnAddC.Text = "Add Category";
            btnAddC.Size = new Size(60, 50);
            btnAddC.Location = new Point(473, 280);
            btnAddC.BackColor = Color.LightGreen;
            btnAddC.ForeColor = Color.Black;
            btnAddC.Click += new EventHandler(btnClick);

            Button btnRemoveC = new Button();
            btnRemoveC.Text = "Remove Category";
            btnRemoveC.Size = new Size(60, 50);
            btnRemoveC.Location = new Point(533, 280);
            btnRemoveC.BackColor = Color.Red;
            btnRemoveC.ForeColor = Color.Black;
            btnRemoveC.Click += new EventHandler(btnClick);

            this.Controls.Add(btnAddC);
            this.Controls.Add(btnRemoveC);

            cBox_filter.Enabled = false;

            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");

            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Cokelat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dgv_product.DataSource = dtProdukSimpan;
            
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");

            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (!cBox_filter.Items.Contains(dtCategory.Rows[i][1].ToString()) && !cBox_category.Items.Contains(dtCategory.Rows[i][1].ToString()))
                {
                    cBox_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                    cBox_category.Items.Add(dtCategory.Rows[i][1].ToString());
                }
            }

            dgv_category.DataSource = dtCategory;

            dgv_product.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv_category.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        public void btnClick(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            dgv_product.DataSource = dtProdukSimpan;

            if (button.Text == "Add Product")
            {
                if (tBox_namaDetails.Text == "" || cBox_category.SelectedItem == null || tBox_harga.Text == "" || tBox_stock.Text == "")
                {
                    MessageBox.Show("Details belum terisi lengkap", "Error");
                }
                else
                {
                    string namaDetails = tBox_namaDetails.Text.ToUpper();

                    int angkaTerbesar = 0;

                    foreach (DataRow rowSimpan in dtProdukSimpan.Rows)
                    {
                        if (rowSimpan["ID Product"].ToString().ToUpper()[0] == namaDetails[0])
                        {
                            int angkaCategory = Convert.ToInt32(rowSimpan["ID Product"].ToString().Substring(1));

                            if (angkaCategory > angkaTerbesar)
                            {
                                angkaTerbesar = angkaCategory;
                            }
                        }
                    }

                    foreach (DataRow rowCategory in dtCategory.Rows)
                    {
                        if (cBox_category.SelectedItem.ToString() == rowCategory["Nama Category"].ToString())
                        {
                            string idProduct = "";

                            int urutanProduct = angkaTerbesar + 1;

                            if (urutanProduct < 10)
                            {
                                idProduct = namaDetails[0] + "00" + urutanProduct.ToString();
                            }
                            else if (urutanProduct >= 10 && urutanProduct < 100)
                            {
                                idProduct = namaDetails[0] + "0" + urutanProduct.ToString();
                            }
                            else if (urutanProduct >= 100 && urutanProduct < 1000)
                            {
                                idProduct = namaDetails[0] + urutanProduct.ToString();
                            }

                            dtProdukSimpan.Rows.Add(idProduct, tBox_namaDetails.Text, tBox_harga.Text, tBox_stock.Text, rowCategory["ID Category"].ToString());
                        }
                    }
                }
            }
            else if (button.Text == "Add Category")
            {
                if (tBox_nama.Text == "")
                {
                    MessageBox.Show("Nama kategori belum diisi", "Error");
                }
                else
                {
                    bool exist = false;

                    foreach (DataRow rowCategory in dtCategory.Rows)
                    {
                        if (rowCategory["Nama Category"].ToString().ToLower() == tBox_nama.Text.ToLower())
                        {
                            exist = true;
                            break;
                        }
                    }

                    if (exist)
                    {
                        MessageBox.Show("Nama category sudah terdaftar", "Error");
                    }
                    else
                    {
                        int angkaTerbesar = 0;

                        foreach (DataRow row in dtCategory.Rows)
                        {
                            int angkaCategory = Convert.ToInt32(row["ID Category"].ToString().Substring(1));

                            if (angkaCategory > angkaTerbesar)
                            {
                                angkaTerbesar = angkaCategory;
                            }
                        }

                        dtCategory.Rows.Add(("C" + (angkaTerbesar + 1).ToString()), tBox_nama.Text);

                        cBox_filter.Items.Add(tBox_nama.Text);
                        cBox_category.Items.Add(tBox_nama.Text);
                    }
                }
            }
            else if (button.Text == "Edit Product")
            {
                if (dgv_product.CurrentCell == null)
                {
                    MessageBox.Show("Pilih produk yang mau diedit terlebih dahulu");
                }
                else
                {
                    if (tBox_namaDetails.Text == "" || cBox_category.SelectedItem == null || tBox_harga.Text == "" || tBox_stock.Text == "")
                    {
                        MessageBox.Show("Details belum terisi lengkap", "Error");
                    }
                    else
                    {
                        int indexRow = dgv_product.CurrentCell.RowIndex;

                        if (tBox_stock.Text == "0")
                        {
                            dtProdukSimpan.Rows.RemoveAt(indexRow);
                        }
                        else
                        {
                            foreach (DataRow rowCategory in dtCategory.Rows)
                            {
                                if (cBox_category.SelectedItem.ToString() == rowCategory["Nama Category"].ToString())
                                {
                                    dtProdukSimpan.Rows[indexRow][4] = rowCategory["ID Category"].ToString();
                                }
                            }

                            dtProdukSimpan.Rows[indexRow][0] = dtProdukSimpan.Rows[indexRow][0];
                            dtProdukSimpan.Rows[indexRow][1] = tBox_namaDetails.Text;
                            dtProdukSimpan.Rows[indexRow][2] = tBox_harga.Text;
                            dtProdukSimpan.Rows[indexRow][3] = tBox_stock.Text;
                        }
                    }
                }
            }
            else if (button.Text == "Remove Product")
            {
                if (dgv_product.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Pilih produk yang mau dihapus terlebih dahulu", "Error");
                }
                else if (dgv_product.SelectedRows.Count == 1)
                {
                    int indexRow = dgv_product.CurrentCell.RowIndex;

                    dtProdukSimpan.Rows.RemoveAt(indexRow);
                }
            }
            else if (button.Text == "Remove Category")
            {
                if (dgv_category.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Pilih kategori yang mau dihapus terlebih dahulu", "Error");
                }
                else if (dgv_category.SelectedRows.Count == 1)
                {
                    int indexRow = dgv_category.CurrentCell.RowIndex;

                    List<DataRow> rowsDihapus = new List<DataRow>();

                    foreach (DataRow rowSimpan in dtProdukSimpan.Rows)
                    {
                        if (dtCategory.Rows[indexRow][0].ToString() == rowSimpan["ID Category"].ToString())
                        {
                            rowsDihapus.Add(rowSimpan);
                        }
                    }

                    foreach (DataRow row in rowsDihapus)
                    {
                        dtProdukSimpan.Rows.Remove(row);
                    }

                    cBox_filter.Items.Remove(dtCategory.Rows[indexRow][1].ToString());
                    cBox_category.Items.Remove(dtCategory.Rows[indexRow][1].ToString());

                    dtCategory.Rows.RemoveAt(indexRow);
                }
            }

            tBox_namaDetails.Clear();
            cBox_category.SelectedItem = null;
            tBox_harga.Clear();
            tBox_stock.Clear();
            tBox_nama.Clear();
            cBox_filter.SelectedItem = null;

            dgv_product.ClearSelection();
            dgv_category.ClearSelection();
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            cBox_filter.Enabled = true;
        }

        private void cBox_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cBox_filter.SelectedItem != null)
            {
                dtProdukTampil.Clear();

                foreach (DataRow rowCategory in dtCategory.Rows)
                {
                    if (cBox_filter.SelectedItem.ToString() == rowCategory["Nama Category"].ToString())
                    {
                        if (dtProdukTampil.Columns.Count == 0)
                        {
                            foreach (DataColumn columnSimpan in dtProdukSimpan.Columns)
                            {
                                dtProdukTampil.Columns.Add(columnSimpan.ColumnName);
                            }
                        }

                        foreach (DataRow rowSimpan in dtProdukSimpan.Rows)
                        {
                            if (rowSimpan["ID Category"].ToString() == rowCategory["ID Category"].ToString())
                            {
                                dtProdukTampil.Rows.Add(rowSimpan.ItemArray);
                            }
                        }

                        break;
                    }
                }

                dgv_product.DataSource = dtProdukTampil;

                dgv_product.ClearSelection();
            }         
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            dgv_product.DataSource = dtProdukSimpan;

            tBox_namaDetails.Clear();
            cBox_category.SelectedItem = null;
            tBox_harga.Clear();
            tBox_stock.Clear();
            tBox_nama.Clear();
            cBox_filter.SelectedItem = null;

            dgv_product.ClearSelection();
        }

        private void dgv_product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tBox_namaDetails.Clear();
            cBox_category.SelectedItem = null;
            tBox_harga.Clear();
            tBox_stock.Clear();

            DataGridViewRow dtProduct = dgv_product.CurrentRow;

            tBox_namaDetails.Text = dtProduct.Cells[1].Value.ToString();

            foreach (DataRow rowCategory in dtCategory.Rows)
            {
                if (rowCategory["ID Category"].ToString() == dtProduct.Cells[4].Value.ToString())
                {
                    cBox_category.SelectedItem = rowCategory["Nama Category"].ToString();
                }
            }

            tBox_harga.Text = dtProduct.Cells[2].Value.ToString();
            tBox_stock.Text = dtProduct.Cells[3].Value.ToString();
        }

        private void dgv_category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tBox_nama.Clear();

            DataGridViewRow dataCategory = dgv_category.CurrentRow;

            tBox_nama.Text = dataCategory.Cells[1].Value.ToString();
        }

        private void tBox_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tBox_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
