﻿namespace TH05
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_product = new System.Windows.Forms.Label();
            this.dgv_product = new System.Windows.Forms.DataGridView();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.cBox_filter = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv_category = new System.Windows.Forms.DataGridView();
            this.lb_namaCategory = new System.Windows.Forms.Label();
            this.tBox_nama = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_namaDetails = new System.Windows.Forms.Label();
            this.lb_category = new System.Windows.Forms.Label();
            this.lb_harga = new System.Windows.Forms.Label();
            this.lb_stok = new System.Windows.Forms.Label();
            this.tBox_namaDetails = new System.Windows.Forms.TextBox();
            this.cBox_category = new System.Windows.Forms.ComboBox();
            this.tBox_harga = new System.Windows.Forms.TextBox();
            this.tBox_stock = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_product
            // 
            this.lb_product.AutoSize = true;
            this.lb_product.Font = new System.Drawing.Font("Arial", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_product.Location = new System.Drawing.Point(56, 51);
            this.lb_product.Name = "lb_product";
            this.lb_product.Size = new System.Drawing.Size(160, 44);
            this.lb_product.TabIndex = 0;
            this.lb_product.Text = "Product";
            // 
            // dgv_product
            // 
            this.dgv_product.AllowUserToAddRows = false;
            this.dgv_product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_product.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_product.Location = new System.Drawing.Point(64, 145);
            this.dgv_product.Name = "dgv_product";
            this.dgv_product.ReadOnly = true;
            this.dgv_product.RowHeadersVisible = false;
            this.dgv_product.RowHeadersWidth = 82;
            this.dgv_product.RowTemplate.Height = 33;
            this.dgv_product.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_product.Size = new System.Drawing.Size(649, 395);
            this.dgv_product.TabIndex = 1;
            this.dgv_product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_product_CellClick);
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(340, 84);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(86, 37);
            this.btn_all.TabIndex = 2;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(443, 84);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(86, 37);
            this.btn_filter.TabIndex = 3;
            this.btn_filter.Text = "Filter:";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // cBox_filter
            // 
            this.cBox_filter.FormattingEnabled = true;
            this.cBox_filter.Location = new System.Drawing.Point(548, 87);
            this.cBox_filter.Name = "cBox_filter";
            this.cBox_filter.Size = new System.Drawing.Size(165, 33);
            this.cBox_filter.TabIndex = 4;
            this.cBox_filter.SelectedIndexChanged += new System.EventHandler(this.cBox_filter_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(840, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 44);
            this.label1.TabIndex = 5;
            this.label1.Text = "Category";
            // 
            // dgv_category
            // 
            this.dgv_category.AllowUserToAddRows = false;
            this.dgv_category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_category.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_category.Location = new System.Drawing.Point(848, 145);
            this.dgv_category.Name = "dgv_category";
            this.dgv_category.ReadOnly = true;
            this.dgv_category.RowHeadersVisible = false;
            this.dgv_category.RowHeadersWidth = 82;
            this.dgv_category.RowTemplate.Height = 33;
            this.dgv_category.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_category.Size = new System.Drawing.Size(331, 293);
            this.dgv_category.TabIndex = 6;
            this.dgv_category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_category_CellClick);
            // 
            // lb_namaCategory
            // 
            this.lb_namaCategory.AutoSize = true;
            this.lb_namaCategory.Location = new System.Drawing.Point(841, 482);
            this.lb_namaCategory.Name = "lb_namaCategory";
            this.lb_namaCategory.Size = new System.Drawing.Size(74, 25);
            this.lb_namaCategory.TabIndex = 7;
            this.lb_namaCategory.Text = "Nama:";
            // 
            // tBox_nama
            // 
            this.tBox_nama.Location = new System.Drawing.Point(922, 479);
            this.tBox_nama.Name = "tBox_nama";
            this.tBox_nama.Size = new System.Drawing.Size(257, 31);
            this.tBox_nama.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(54, 597);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 44);
            this.label2.TabIndex = 9;
            this.label2.Text = "Details";
            // 
            // lb_namaDetails
            // 
            this.lb_namaDetails.AutoSize = true;
            this.lb_namaDetails.Location = new System.Drawing.Point(59, 673);
            this.lb_namaDetails.Name = "lb_namaDetails";
            this.lb_namaDetails.Size = new System.Drawing.Size(74, 25);
            this.lb_namaDetails.TabIndex = 10;
            this.lb_namaDetails.Text = "Nama:";
            // 
            // lb_category
            // 
            this.lb_category.AutoSize = true;
            this.lb_category.Location = new System.Drawing.Point(28, 732);
            this.lb_category.Name = "lb_category";
            this.lb_category.Size = new System.Drawing.Size(105, 25);
            this.lb_category.TabIndex = 11;
            this.lb_category.Text = "Category:";
            // 
            // lb_harga
            // 
            this.lb_harga.AutoSize = true;
            this.lb_harga.Location = new System.Drawing.Point(57, 794);
            this.lb_harga.Name = "lb_harga";
            this.lb_harga.Size = new System.Drawing.Size(76, 25);
            this.lb_harga.TabIndex = 12;
            this.lb_harga.Text = "Harga:";
            // 
            // lb_stok
            // 
            this.lb_stok.AutoSize = true;
            this.lb_stok.Location = new System.Drawing.Point(72, 860);
            this.lb_stok.Name = "lb_stok";
            this.lb_stok.Size = new System.Drawing.Size(61, 25);
            this.lb_stok.TabIndex = 13;
            this.lb_stok.Text = "Stok:";
            // 
            // tBox_namaDetails
            // 
            this.tBox_namaDetails.Location = new System.Drawing.Point(150, 670);
            this.tBox_namaDetails.Name = "tBox_namaDetails";
            this.tBox_namaDetails.Size = new System.Drawing.Size(563, 31);
            this.tBox_namaDetails.TabIndex = 14;
            // 
            // cBox_category
            // 
            this.cBox_category.FormattingEnabled = true;
            this.cBox_category.Location = new System.Drawing.Point(150, 729);
            this.cBox_category.Name = "cBox_category";
            this.cBox_category.Size = new System.Drawing.Size(174, 33);
            this.cBox_category.TabIndex = 15;
            // 
            // tBox_harga
            // 
            this.tBox_harga.Location = new System.Drawing.Point(150, 791);
            this.tBox_harga.Name = "tBox_harga";
            this.tBox_harga.Size = new System.Drawing.Size(174, 31);
            this.tBox_harga.TabIndex = 16;
            this.tBox_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_harga_KeyPress);
            // 
            // tBox_stock
            // 
            this.tBox_stock.Location = new System.Drawing.Point(150, 857);
            this.tBox_stock.Name = "tBox_stock";
            this.tBox_stock.Size = new System.Drawing.Size(174, 31);
            this.tBox_stock.TabIndex = 17;
            this.tBox_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBox_stock_KeyPress);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1232, 1127);
            this.Controls.Add(this.tBox_stock);
            this.Controls.Add(this.tBox_harga);
            this.Controls.Add(this.cBox_category);
            this.Controls.Add(this.tBox_namaDetails);
            this.Controls.Add(this.lb_stok);
            this.Controls.Add(this.lb_harga);
            this.Controls.Add(this.lb_category);
            this.Controls.Add(this.lb_namaDetails);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tBox_nama);
            this.Controls.Add(this.lb_namaCategory);
            this.Controls.Add(this.dgv_category);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cBox_filter);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.dgv_product);
            this.Controls.Add(this.lb_product);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_product;
        private System.Windows.Forms.DataGridView dgv_product;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cBox_filter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgv_category;
        private System.Windows.Forms.Label lb_namaCategory;
        private System.Windows.Forms.TextBox tBox_nama;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_namaDetails;
        private System.Windows.Forms.Label lb_category;
        private System.Windows.Forms.Label lb_harga;
        private System.Windows.Forms.Label lb_stok;
        private System.Windows.Forms.TextBox tBox_namaDetails;
        private System.Windows.Forms.ComboBox cBox_category;
        private System.Windows.Forms.TextBox tBox_harga;
        private System.Windows.Forms.TextBox tBox_stock;
    }
}

